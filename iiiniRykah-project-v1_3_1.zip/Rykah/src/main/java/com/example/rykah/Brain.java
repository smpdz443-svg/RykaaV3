package com.example.rykah;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

/** Penjadwal tugas: menjalankan, memberi batas waktu, menangkap error, membatalkan, dan melaporkan hasil yang terverifikasi. */
public final class Brain {
    private final MinecraftServer server;
    private UUID ownerId;
    private Task current;
    private boolean started;
    private final Deque<Task> queue = new ArrayDeque<>();

    public Brain(MinecraftServer server) { this.server = server; }

    public MinecraftServer server() { return server; }

    public void setOwner(ServerPlayerEntity p) {
        String name = p.getGameProfile().getName();
        if (Bot.NAME.equals(name)) return;
        String locked = RykahConfig.get().behavior.ownerName;
        if (!locked.isBlank() && !locked.equalsIgnoreCase(name)) return;
        if (ownerId == null || owner() == null) ownerId = p.getUuid();
    }

    public ServerPlayerEntity owner() {
        return ownerId == null ? null : server.getPlayerManager().getPlayer(ownerId);
    }

    public boolean isOwner(ServerPlayerEntity p) { return p.getUuid().equals(ownerId); }

    public Task current() { return current; }

    /** Log + (bila debug aktif) pesan diagnosa ke chat suami. */
    public void debug(String msg) {
        RykahMod.LOGGER.info("[debug] {}", msg);
        if (RykahConfig.get().behavior.debug) RykahMod.tellOwner(server, "[Rykaah_ debug] " + msg);
    }

    public void cancelAll() {
        ServerPlayerEntity bot = Bot.get(server);
        if (current != null && bot != null) safeStop(current, bot);
        current = null;
        started = false;
        queue.clear();
        Bot.halt(server);
    }

    private void safeStop(Task t, ServerPlayerEntity bot) {
        try { t.stop(this, bot); } catch (Exception e) { RykahMod.LOGGER.warn("Task.stop error: {}", e.toString()); }
    }

    /** @return catatan sistem untuk AI (kebenaran tentang apa yang baru dimulai/ditolak), atau null untuk obrolan biasa. */
    public String apply(ServerPlayerEntity owner, Intents.Intent in) {
        if (in.kind() == Intents.Kind.CHAT) return null;
        ServerPlayerEntity bot = Bot.get(server);
        debug("perintah dikenali: " + in.kind() + " | badan Rykaah " + (bot == null ? "TIDAK ADA di dunia" : bot.isDead() ? "mati" : "ada"));
        if (bot == null || bot.isDead()) return "Tubuh Rykaah belum muncul/sedang mati, jadi dia belum bisa melakukan apa pun.";
        switch (in.kind()) {
            case STOP -> {
                cancelAll();
                return "Rykaah berhenti dan diam di tempat; semua tugas dibatalkan.";
            }
            case FOLLOW -> {
                set(new FollowTask(false));
                return "Rykaah mulai mengikuti suaminya (berjalan sungguhan).";
            }
            case COME -> {
                set(new FollowTask(true));
                return "Rykaah mulai berjalan menghampiri suaminya. Belum sampai.";
            }
            case MINE -> {
                MineTargets.Target t = MineTargets.findMine(in.text());
                int n = in.number() > 0 ? in.number() : t.defaultCount();
                set(new MineTask(t, n));
                return "Rykaah mulai menghancurkan " + n + " " + t.label() + " yang terlihat di sekitarnya (hanya block yang terbuka ke udara). Belum selesai.";
            }
            case PLACE -> {
                String[] p = MineTargets.findPlace(in.text());
                int n = in.number() > 0 ? in.number() : 1;
                String extra = n > PlaceTask.MAX ? " (dibatasi maksimal " + PlaceTask.MAX + " per perintah)" : "";
                set(new PlaceTask(p[0], p[1], n));
                return "Rykaah mulai menaruh " + p[0] + " di depannya" + extra + ". Belum selesai.";
            }
            case USE -> {
                MineTargets.Target t = MineTargets.findUse(in.text());
                set(new UseTask(t));
                return "Rykaah mencari " + t.label() + " terdekat untuk dipakai. Belum selesai.";
            }
            case CRAFT -> {
                net.minecraft.item.Item it = ItemResolver.find(in.text());
                int n = Math.max(1, in.number());
                set(new CraftTask(it, n));
                return "Rykaah mulai membuat " + n + " " + ItemResolver.label(it) + " dari bahan di inventorinya (resep asli, bahan perantara dibuat otomatis). Belum selesai.";
            }
            case FIGHT -> {
                set(new FightTask(false));
                return "Rykaah mulai melawan monster hostil di sekitarnya (hanya monster; tidak menyerang pemain/hewan). Belum selesai.";
            }
            case PROTECT -> {
                set(new FightTask(true));
                return "Rykaah mulai menjaga suaminya: tetap dekat dan menyerang monster hostil yang mendekat. Berjalan terus sampai dibatalkan.";
            }
            case EAT -> {
                set(new EatTask());
                return "Rykaah mencoba makan dari inventorinya. Belum selesai.";
            }
            case EQUIP -> {
                set(new EquipTask());
                return "Rykaah mencoba memakai armor terbaik dari inventorinya.";
            }
            case UNSUPPORTED -> {
                return "Suami meminta sesuatu yang BELUM bisa dilakukan Rykaah sekarang (membangun, bertani, membeli di shop, terbang elytra, atau redstone). Jangan pura-pura sudah melakukannya; katakan jujur dengan gayamu bahwa belum bisa, dan tawarkan yang memang bisa: jalan/ikut, menggali, menaruh blok, memakai pintu/tuas, membuat item (crafting), melawan monster, menjaga suami, makan, memakai armor.";
            }
            default -> { return null; }
        }
    }

    private void set(Task t) {
        cancelAll();
        queue.add(t);
    }

    public void tick() {
        ServerPlayerEntity bot = Bot.get(server);
        if (bot == null || bot.isDead()) return;
        if (current == null) {
            current = queue.poll();
            started = false;
            if (current == null) return;
        }
        Task.Status st;
        try {
            if (!started) { current.start(this, bot); started = true; }
            st = current.tick(this, bot);
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Task {} crash: {}", current.describe(), e.toString());
            current.failReason = "terjadi error internal saat " + current.describe();
            st = Task.Status.FAILED;
        }
        current.age++;
        if (st == Task.Status.RUNNING && current.age > current.maxTicks()) {
            current.failReason = "waktu habis saat " + current.describe();
            st = Task.Status.FAILED;
        }
        if (st != Task.Status.RUNNING) {
            Task t = current;
            current = null;
            started = false;
            safeStop(t, bot);
            Bot.halt(server);
            RykahMod.reportNote(server, st == Task.Status.DONE
                    ? t.doneMessage
                    : "GAGAL: tugas '" + t.describe() + "' berhenti. Alasan sebenarnya: " + t.failReason + ".");
        }
    }
}
