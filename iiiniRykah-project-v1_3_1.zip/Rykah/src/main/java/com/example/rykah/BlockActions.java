package com.example.rykah;

import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Interaksi block seperti pemain biasa lewat ServerPlayerInteractionManager:
 * waktu mining nyata (alat + efek), cek jangkauan dan line-of-sight, dan setiap hasil DIVERIFIKASI dari state dunia.
 */
public final class BlockActions {
    public static final double REACH = 4.5;

    public enum Result { IN_PROGRESS, DONE, GONE, FAILED, TOO_FAR, NO_SIGHT, NO_TOOL }

    private BlockActions() {}

    public static void lookAt(ServerPlayerEntity p, Vec3d t) {
        Vec3d e = p.getEyePos();
        double dx = t.x - e.x, dy = t.y - e.y, dz = t.z - e.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        p.setYaw(yaw);
        p.setPitch(pitch);
        p.setHeadYaw(yaw);
    }

    public static boolean inReach(ServerPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= REACH * REACH;
    }

    public static boolean hasLineOfSight(ServerPlayerEntity p, BlockPos pos) {
        ServerWorld w = p.getServerWorld();
        BlockHitResult hit = w.raycast(new RaycastContext(p.getEyePos(), Vec3d.ofCenter(pos),
                RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, p));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(pos);
    }

    /** Pilih slot hotbar tercepat untuk block ini (slot sekarang menang bila seri). */
    public static void equipBest(ServerPlayerEntity p, BlockState state) {
        int best = p.getInventory().selectedSlot;
        float bestSpeed = p.getInventory().getStack(best).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            float s = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (s > bestSpeed) { bestSpeed = s; best = i; }
        }
        p.getInventory().selectedSlot = best;
    }

    /** Satu sesi menghancurkan satu block; panggil tick() tiap tick sampai bukan IN_PROGRESS. */
    public static final class MiningSession {
        private final BlockPos pos;
        private float progress;
        private int ticks;

        public MiningSession(BlockPos pos) { this.pos = pos; }

        public BlockPos pos() { return pos; }

        public Result tick(ServerPlayerEntity p) {
            ServerWorld w = p.getServerWorld();
            BlockState state = w.getBlockState(pos);
            if (state.isAir()) return Result.GONE;
            if (state.getHardness(w, pos) < 0 && !p.isCreative()) return Result.FAILED;
            if (!inReach(p, pos)) return Result.TOO_FAR;
            if (!hasLineOfSight(p, pos)) return Result.NO_SIGHT;
            equipBest(p, state);
            if (state.isToolRequired() && !p.getMainHandStack().isSuitableFor(state)) return Result.NO_TOOL;
            if (++ticks > 1200) return Result.FAILED;

            lookAt(p, Vec3d.ofCenter(pos));
            p.swingHand(Hand.MAIN_HAND, true);
            progress += state.calcBlockBreakingDelta(p, w, pos);
            w.setBlockBreakingInfo(p.getId(), pos, Math.min(9, (int) (progress * 10f)));
            if (progress < 1f) return Result.IN_PROGRESS;

            w.setBlockBreakingInfo(p.getId(), pos, -1);
            boolean ok = p.interactionManager.tryBreakBlock(pos);
            // Terverifikasi: block aslinya benar-benar sudah tidak ada di posisi itu.
            return (ok && !w.getBlockState(pos).isOf(state.getBlock())) ? Result.DONE : Result.FAILED;
        }

        public void abort(ServerPlayerEntity p) {
            p.getServerWorld().setBlockBreakingInfo(p.getId(), pos, -1);
        }
    }

    /** Klik kanan block (pintu, trapdoor, gerbang, tombol, tuas). DONE hanya bila state block berubah. */
    public static Result use(ServerPlayerEntity p, BlockPos pos) {
        ServerWorld w = p.getServerWorld();
        BlockState before = w.getBlockState(pos);
        if (before.isAir()) return Result.GONE;
        if (!inReach(p, pos)) return Result.TOO_FAR;
        if (!hasLineOfSight(p, pos)) return Result.NO_SIGHT;
        Vec3d hit = Vec3d.ofCenter(pos);
        lookAt(p, hit);
        p.swingHand(Hand.MAIN_HAND, true);
        ActionResult r = p.interactionManager.interactBlock(p, w, p.getMainHandStack(), Hand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, pos, false));
        if (!r.isAccepted()) return Result.FAILED;
        return w.getBlockState(pos).equals(before) ? Result.FAILED : Result.DONE;
    }

    /** Taruh block yang sedang dipegang di posisi 'target' dengan mengklik tetangga padat. DONE hanya bila target terisi. */
    public static Result placeAt(ServerPlayerEntity p, BlockPos target) {
        ServerWorld w = p.getServerWorld();
        ItemStack held = p.getMainHandStack();
        if (!(held.getItem() instanceof BlockItem)) return Result.FAILED;
        if (!w.getBlockState(target).isReplaceable()) return Result.FAILED;
        if (!inReach(p, target)) return Result.TOO_FAR;
        for (Direction d : Direction.values()) {
            BlockPos n = target.offset(d);
            BlockState ns = w.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.isSolidBlock(w, n)) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(Vec3d.of(face.getVector()).multiply(0.5));
            lookAt(p, hit);
            p.swingHand(Hand.MAIN_HAND, true);
            ActionResult r = p.interactionManager.interactBlock(p, w, held, Hand.MAIN_HAND,
                    new BlockHitResult(hit, face, n, false));
            if (r.isAccepted() && !w.getBlockState(target).isReplaceable()) return Result.DONE;
        }
        return Result.FAILED;
    }
}
