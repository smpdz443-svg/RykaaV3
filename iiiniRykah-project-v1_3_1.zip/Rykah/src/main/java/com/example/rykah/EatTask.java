package com.example.rykah;

import net.minecraft.server.network.ServerPlayerEntity;

/** Makan sungguhan; selesai hanya bila tingkat lapar atau jumlah makanan benar-benar berubah. */
public final class EatTask extends Task {
    private int foodBefore, foodItemsBefore;
    private boolean started;
    private int waited;

    @Override public String describe() { return "makan"; }

    @Override public int maxTicks() { return 20 * 15; }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        if (!started) {
            foodBefore = bot.getHungerManager().getFoodLevel();
            foodItemsBefore = Gear.foodCount(bot);
            if (foodBefore >= 20) { failReason = "Rykaah sudah kenyang (lapar 20/20)"; return Status.FAILED; }
            if (foodItemsBefore == 0) { failReason = "Rykaah nggak punya makanan di inventori"; return Status.FAILED; }
            Bot.halt(brain.server());
            if (!Gear.startEating(bot)) { failReason = "Rykaah nggak bisa mulai makan (server menolak atau tidak ada makanan yang bisa dimakan)"; return Status.FAILED; }
            started = true;
            return Status.RUNNING;
        }
        if (bot.isUsingItem()) return Status.RUNNING;
        if (++waited < 3) return Status.RUNNING;
        int now = bot.getHungerManager().getFoodLevel();
        if (now > foodBefore || Gear.foodCount(bot) < foodItemsBefore) {
            doneMessage = "Rykaah sudah makan: lapar " + foodBefore + " -> " + now + " (terverifikasi).";
            return Status.DONE;
        }
        failReason = "makanannya nggak termakan sampai habis";
        return Status.FAILED;
    }
}
