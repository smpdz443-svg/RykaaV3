package com.example.rykah;

import net.minecraft.entity.mob.AbstractPiglinEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Melawan monster sungguhan (melee, cooldown serangan asli). Hanya menyerang Monster hostil: TIDAK PERNAH pemain (termasuk suami),
 * hewan, villager, atau mob netral yang sedang tidak marah (enderman, piglin zombi). protect=true: tetap dekat suami dan menjaganya
 * sampai dibatalkan; protect=false: bunuh monster di sekitar lalu selesai. Mundur ke suami saat HP rendah, makan bila perlu.
 * Kill dihitung hanya bila target yang sudah diserang benar-benar mati.
 */
public final class FightTask extends Task {
    private static final double SEARCH = 14.0;
    private static final double ATTACK_RANGE = 3.0;

    private final boolean protect;
    private final Set<UUID> engaged = new HashSet<>();
    private MobEntity target;
    private int kills, idleTicks, noWeaponWarn;

    public FightTask(boolean protect) { this.protect = protect; }

    @Override public String describe() { return protect ? "menjaga suami" : "melawan monster sekitar"; }

    @Override public String progress() { return kills + " monster dikalahkan"; }

    @Override public int maxTicks() { return protect ? Integer.MAX_VALUE : 20 * 60 * 3; }

    private boolean valid(MobEntity m) {
        if (!m.isAlive() || !(m instanceof Monster)) return false;
        // mob netral (enderman, piglin, piglin zombi) hanya dilawan bila mereka sudah menargetkan seseorang
        boolean neutral = m instanceof EndermanEntity || m instanceof AbstractPiglinEntity || m instanceof net.minecraft.entity.mob.ZombifiedPiglinEntity;
        return !neutral || m.getTarget() != null;
    }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        ServerPlayerEntity owner = brain.owner();
        // kill terverifikasi
        if (target != null && !target.isAlive() && engaged.contains(target.getUuid())) { kills++; target = null; }

        if (bot.isUsingItem()) { Bot.halt(brain.server()); return Status.RUNNING; } // sedang makan

        float hp = bot.getHealth();
        if (hp < 10 && bot.getHungerManager().getFoodLevel() < 20 && Gear.foodCount(bot) > 0 && (target == null || bot.distanceTo(target) > 4)) {
            if (Gear.startEating(bot)) return Status.RUNNING;
        }
        if (hp < 6) { // mundur
            if (owner != null && owner.getWorld() == bot.getWorld()) Nav.walkTo(brain.server(), bot, owner.getPos(), 2.0, true);
            else Bot.halt(brain.server());
            if (age % 100 == 0) brain.debug("HP rendah (" + Math.round(hp) + "), mundur dulu");
            return Status.RUNNING;
        }

        if (target == null || !valid(target) || bot.distanceTo(target) > SEARCH + 6) target = pick(bot, owner);
        if (target == null) {
            if (protect) {
                if (owner != null && owner.getWorld() == bot.getWorld()) Nav.walkTo(brain.server(), bot, owner.getPos(), 3.0, true);
                else Bot.halt(brain.server());
                return Status.RUNNING;
            }
            Bot.halt(brain.server());
            if (++idleTicks > 30) {
                doneMessage = kills == 0 ? "Rykaah mencari tapi nggak ada monster hostil di sekitar (radius " + (int) SEARCH + " blok)."
                        : "Rykaah selesai bertarung: " + kills + " monster dikalahkan (terverifikasi mati).";
                return Status.DONE;
            }
            return Status.RUNNING;
        }
        idleTicks = 0;

        if (!Gear.equipBestWeapon(bot) && noWeaponWarn++ == 0) brain.debug("nggak punya pedang/kapak, bertarung dengan tangan kosong");

        double d = bot.distanceTo(target);
        if (target instanceof CreeperEntity && d < 3.5 && hp < 14) { // jangan adu dekat dengan creeper saat lemah
            failReason = "ada creeper terlalu dekat dan HP-ku rendah, aku mundur demi keselamatan";
            return Status.FAILED;
        }
        if (d > ATTACK_RANGE) {
            Nav.walkTo(brain.server(), bot, target.getPos(), 2.0, true);
            return Status.RUNNING;
        }
        Bot.halt(brain.server());
        BlockActions.lookAt(bot, target.getEyePos());
        if (bot.getAttackCooldownProgress(0.5f) >= 1.0f && bot.canSee(target)) {
            engaged.add(target.getUuid());
            bot.attack(target);
            bot.swingHand(Hand.MAIN_HAND);
        }
        return Status.RUNNING;
    }

    private MobEntity pick(ServerPlayerEntity bot, ServerPlayerEntity owner) {
        List<MobEntity> list = bot.getServerWorld().getEntitiesByClass(MobEntity.class, bot.getBoundingBox().expand(SEARCH), this::valid);
        if (protect && owner != null && owner.getWorld() == bot.getWorld())
            list.removeIf(m -> m.distanceTo(owner) > 16);
        return list.stream().min(Comparator.comparingDouble(m -> m.squaredDistanceTo(bot))).orElse(null);
    }

    @Override public void stop(Brain brain, ServerPlayerEntity bot) { Bot.halt(brain.server()); }
}
