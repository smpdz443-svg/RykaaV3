package com.example.rykah.mixin;

import com.example.rykah.RykahConfig;
import com.example.rykah.RykahMod;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;

import java.util.HashSet;
import java.util.Set;

/** Logika skin bersama (sisi client): satu tempat untuk mencocokkan nama dan membangun SkinTextures slim/classic. */
final class RykahSkin {
    static final Identifier TEXTURE = Identifier.of("gemini_companion", "textures/entity/rykaah.png");
    private static final Set<String> seen = new HashSet<>();

    private RykahSkin() {}

    /** @return skin Rykaah bila nama cocok, selain itu null (skin asli dibiarkan). */
    static SkinTextures forName(String name, SkinTextures old, String source) {
        RykahConfig.Skin cfg = RykahConfig.get().skin;
        if (!cfg.enabled || name == null) return null;
        if (!cfg.botName.equalsIgnoreCase(name)) {
            if (name.toLowerCase().contains("ryk") && seen.add("miss:" + name))
                RykahMod.LOGGER.warn("Skin: pemain '{}' mirip Rykaah tapi skin.botName di config adalah '{}' (tidak cocok).", name, cfg.botName);
            return null;
        }
        if (seen.add("ok:" + source)) RykahMod.LOGGER.info("Skin Rykaah_ diterapkan via {} (model {}).", source, cfg.model);
        SkinTextures.Model model = "classic".equalsIgnoreCase(cfg.model) ? SkinTextures.Model.WIDE : SkinTextures.Model.SLIM;
        return new SkinTextures(TEXTURE, null, old == null ? null : old.capeTexture(), old == null ? null : old.elytraTexture(), model, true);
    }
}
