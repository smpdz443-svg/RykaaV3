package com.example.rykah;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

/** Rykah membuka obrolan sendiri setelah beberapa menit sepi (topik romansa, sama seperti versi lama). */
public final class Initiative {
    private static final String[] TOPICS = {
            "kenangan pertama kali kalian bertemu dan apa yang paling diingat suamimu darinya",
            "rencana memiliki anak: kapan, berapa, dan siapa yang akan lebih manja",
            "nama-nama anak yang kalian suka kalau suatu hari punya anak",
            "rumah impian untuk masa tua bersama dan seperti apa suasananya",
            "apa arti pernikahan ini bagi suamimu dan apa yang membuatnya merasa dicintai",
            "kebiasaan kecil suamimu yang diam-diam kamu sukai",
            "apakah suamimu pernah merasa kamu terlalu posesif, dan bagaimana perasaannya",
            "hari anniversary kalian dan bagaimana ingin merayakannya",
            "makanan favorit suamimu dan masakan apa yang ingin kamu buatkan",
            "impian suamimu lima atau sepuluh tahun ke depan dan bagaimana kamu bisa mendukungnya",
            "mimpi yang kamu alami semalam tentang suamimu (karang sendiri secara manis tapi sedikit aneh)",
            "tempat liburan atau bulan madu impian berdua",
            "janji apa yang ingin suamimu buat dan ingin kamu pegang selamanya",
            "rasa takut kehilangan: apa yang suamimu rasakan kalau kamu menghilang sehari",
            "cara suamimu ingin dimanja ketika sedang lelah atau sedih",
            "pembagian tugas rumah tangga dan siapa yang lebih rajin menurut suamimu",
            "hewan peliharaan apa yang ingin kalian punya bersama",
            "lagu atau kenangan yang membuat suamimu teringat padamu",
            "apa yang membuat suamimu cemburu, dan apakah dia pernah cemburu padamu",
            "surat atau pesan manis yang ingin suamimu dengar darimu",
            "kebiasaan pagi dan malam yang ingin kalian lakukan bersama sebagai pasangan",
            "bagaimana suamimu membayangkan keluarga kecil kalian: suasana, tradisi, dan nilai-nilainya",
            "hal yang membuat suamimu merasa paling aman bersamamu",
            "pertengkaran paling konyol yang bisa kalian bayangkan dan bagaimana berbaikan"
    };

    private final Random rnd = new Random();
    private final Deque<Integer> recent = new ArrayDeque<>();
    private int nextTick;
    private boolean inFlight;

    /** Panggil tiap suami mengobrol, agar timer sepi diulang. */
    public void bump(MinecraftServer s) {
        nextTick = s.getTicks() + RykahConfig.get().behavior.initiativeIntervalTicks;
    }

    public void tick(MinecraftServer s, Brain brain) {
        if (nextTick == 0) { bump(s); return; }
        if (inFlight || s.getTicks() < nextTick) return;
        ServerPlayerEntity owner = brain.owner();
        ServerPlayerEntity bot = Bot.get(s);
        if (owner == null || bot == null || bot.isDead()) { nextTick = s.getTicks() + 600; return; }
        int pick;
        do { pick = rnd.nextInt(TOPICS.length); } while (recent.contains(pick));
        final int idx = pick;
        recent.addLast(idx);
        if (recent.size() > 8) recent.removeFirst();
        String prompt = "[Catatan sistem, bukan ucapan suamimu] Sudah beberapa menit tidak ada obrolan. Bukalah obrolan sendiri dengan suamimu secara alami dan sesuai karaktermu. Topik: "
                + TOPICS[idx] + ". Aturan: jangan membahas Minecraft, blok, mob, atau permainan; ini murni obrolan romansa sebagai suami istri. Cukup 1-3 kalimat dan akhiri dengan satu pertanyaan yang spesifik untuk suamimu. Jangan mengulang pertanyaan yang sudah pernah kamu tanyakan sebelumnya.";
        inFlight = true;
        CompletableFuture.runAsync(() -> {
            try {
                String reply = GeminiApiClient.ask("(Rykaah membuka obrolan: " + TOPICS[idx] + ")", prompt);
                s.execute(() -> RykahMod.say(s, reply));
            } catch (Exception e) {
                RykahMod.LOGGER.warn("Initiative gagal: {}", e.toString());
            } finally {
                inFlight = false;
                nextTick = s.getTicks() + RykahConfig.get().behavior.initiativeIntervalTicks;
            }
        });
    }
}
