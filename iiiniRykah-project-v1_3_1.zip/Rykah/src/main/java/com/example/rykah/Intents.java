package com.example.rykah;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pengenal perintah dari chat Indonesia/Inggris informal. Pesan tanpa kata kerja + objek yang jelas dianggap obrolan biasa (CHAT). */
public final class Intents {
    public enum Kind { STOP, FOLLOW, COME, MINE, PLACE, USE, CRAFT, FIGHT, PROTECT, EAT, EQUIP, UNSUPPORTED, CHAT }

    public record Intent(Kind kind, int number, String text) {}

    private static final Pattern STOP = Pattern.compile("\\b(berhenti|stop|diam|stay|batal|cancel)\\b");
    private static final Pattern FOLLOW = Pattern.compile("\\b(ikuti aku|ikut aku|ikuti saya|ikut saya|ikuti|follow me|follow)\\b");
    private static final Pattern COME = Pattern.compile("\\b(kemari|ke sini|kesini|come here)\\b");
    private static final Pattern MINE_VERB = Pattern.compile("\\b(tambang|gali|menggali|mine|mining|ambil|ambilin|cari|carikan|kumpul\\w*|tebang|nebang|potong|chop|collect|hancurkan|hancurin)\\b");
    private static final Pattern PLACE_VERB = Pattern.compile("\\b(pasang|pasangin|taruh|taruhin|letakkan|place)\\b");
    private static final Pattern USE_VERB = Pattern.compile("\\b(buka|bukain|tutup|tutupin|tekan|pencet|tarik|open|close|press|toggle)\\b");
    private static final Pattern CRAFT_VERB = Pattern.compile("\\b(buat|buatkan|buatin|bikin|bikinin|membuat|craft|crafting|make)\\b");
    private static final Pattern PROTECT = Pattern.compile("\\b(lindungi|lindungin|jagain|jaga aku|jaga saya|protect me|protect|guard me)\\b");
    private static final Pattern FIGHT = Pattern.compile("\\b(lawan|serang|hajar|bunuh|basmi|fight|attack|kill)\\b.*\\b(monster|mob|musuh|zombie|zombi|skeleton|laba|spider|semua|enemy|enemies)\\b");
    private static final Pattern EAT = Pattern.compile("\\b(makan dulu|makan gih|kamu makan|rykah makan|makan sana|eat something|makan dong)\\b");
    private static final Pattern EQUIP = Pattern.compile("\\b(pakai armor|pakai armornya|pakai baju besi|pakai zirah|equip armor|pakai pelindung)\\b");
    private static final Pattern UNSUPPORTED = Pattern.compile("\\b(bangun|bangunin|build|tanam|menanam|panen|farming|bertani|beli|belikan|terbang|elytra|redstone)\\b");
    private static final Pattern NUM = Pattern.compile("(\\d{1,3})");

    private Intents() {}

    public static Intent parse(String raw) {
        String t = raw.toLowerCase(Locale.ROOT).trim();
        if (STOP.matcher(t).find()) return new Intent(Kind.STOP, 0, t);
        int n = number(t);
        if (PLACE_VERB.matcher(t).find() && MineTargets.findPlace(t) != null) return new Intent(Kind.PLACE, n, t);
        if (USE_VERB.matcher(t).find() && MineTargets.findUse(t) != null) return new Intent(Kind.USE, 1, t);
        if (CRAFT_VERB.matcher(t).find() && ItemResolver.find(t) != null) return new Intent(Kind.CRAFT, Math.max(n, 1), t);
        if (MINE_VERB.matcher(t).find() && MineTargets.findMine(t) != null) return new Intent(Kind.MINE, n, t);
        if (EQUIP.matcher(t).find()) return new Intent(Kind.EQUIP, 0, t);
        if (EAT.matcher(t).find()) return new Intent(Kind.EAT, 0, t);
        if (PROTECT.matcher(t).find()) return new Intent(Kind.PROTECT, 0, t);
        if (FIGHT.matcher(t).find()) return new Intent(Kind.FIGHT, 0, t);
        if (FOLLOW.matcher(t).find()) return new Intent(Kind.FOLLOW, 0, t);
        if (COME.matcher(t).find()) return new Intent(Kind.COME, 0, t);
        if (UNSUPPORTED.matcher(t).find()) return new Intent(Kind.UNSUPPORTED, 0, t);
        return new Intent(Kind.CHAT, 0, t);
    }

    private static int number(String t) {
        Matcher m = NUM.matcher(t);
        if (!m.find()) return -1;
        return Math.max(1, Math.min(Integer.parseInt(m.group(1)), 256));
    }
}
