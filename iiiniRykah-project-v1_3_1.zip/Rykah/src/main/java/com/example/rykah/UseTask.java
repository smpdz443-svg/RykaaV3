package com.example.rykah;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Klik kanan block terdekat (pintu, trapdoor, gerbang, tombol, tuas); sukses hanya bila state block benar-benar berubah. */
public final class UseTask extends Task {
    private final MineTargets.Target target;
    private BlockPos pos;
    private int goTicks, scans;

    public UseTask(MineTargets.Target target) { this.target = target; }

    @Override public String describe() { return "memakai " + target.label() + " terdekat"; }

    @Override public int maxTicks() { return 20 * 30; }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        if (pos == null) {
            pos = Scan.nearest(bot, target.test(), 8, 4, null, false);
            if (pos == null) { failReason = "tidak ada " + target.label() + " dalam radius 8 blok"; return Status.FAILED; }
        }
        if (!BlockActions.inReach(bot, pos) || !BlockActions.hasLineOfSight(bot, pos)) {
            if (++goTicks > 300) { failReason = target.label() + " tidak bisa kujangkau"; return Status.FAILED; }
            Nav.walkTo(brain.server(), bot, Vec3d.ofCenter(pos), 1.8, false);
            return Status.RUNNING;
        }
        Bot.halt(brain.server());
        BlockActions.Result r = BlockActions.use(bot, pos);
        if (r == BlockActions.Result.DONE) {
            doneMessage = "Rykaah sudah memakai " + target.label() + " (perubahan state block terverifikasi).";
            return Status.DONE;
        }
        failReason = target.label() + " tidak berubah setelah kuklik (mungkin terkunci, pintu besi, atau butuh redstone)";
        return Status.FAILED;
    }

    @Override public void stop(Brain brain, ServerPlayerEntity bot) { Bot.halt(brain.server()); }
}
