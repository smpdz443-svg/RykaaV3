package com.example.rykah;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;

/** Spawn awal, deteksi kematian, respawn terverifikasi, dan laporan kehilangan barang. Setelah respawn Rykah TIDAK melanjutkan tugas lama. */
public final class Lifecycle {
    private static int pendingSpawnAt = -1;
    private static boolean awaiting;
    private static int respawnAt;
    private static int attempts;
    private static int lastInvCount = -1;
    private static int invBeforeDeath;
    private static BlockPos deathPos = BlockPos.ORIGIN;
    private static String deathCause = "";

    private Lifecycle() {}

    public static void onOwnerJoin(MinecraftServer s) {
        if (Bot.get(s) == null) pendingSpawnAt = s.getTicks() + 60;
    }

    public static void onBotDeath(MinecraftServer s, ServerPlayerEntity bot, DamageSource src, Brain brain) {
        invBeforeDeath = Math.max(lastInvCount, 0);
        deathPos = bot.getBlockPos();
        deathCause = src.getType().msgId();
        awaiting = true;
        attempts = 0;
        respawnAt = s.getTicks() + RykahConfig.get().behavior.respawnDelayTicks;
        brain.cancelAll();
        RykahMod.LOGGER.info("Rykaah mati ({}) di {}", deathCause, deathPos.toShortString());
    }

    public static void tick(MinecraftServer s, Brain brain) {
        ServerPlayerEntity bot = Bot.get(s);
        if (!awaiting) {
            if (bot != null && bot.isAlive()) lastInvCount = GameState.countItems(bot);
            if (pendingSpawnAt >= 0 && s.getTicks() >= pendingSpawnAt) {
                pendingSpawnAt = -1;
                ServerPlayerEntity owner = brain.owner();
                if (owner != null && Bot.get(s) == null) {
                    Bot.spawnAt(s, owner);
                    AuthHandler.begin(s);
                }
            }
            return;
        }
        if (s.getTicks() < respawnAt) return;

        if (bot != null && bot.isAlive() && !bot.isDead()) { finish(s, brain, bot); return; } // sudah respawn (oleh Carpet/server)
        if (!RykahConfig.get().behavior.autoRespawn) {
            awaiting = false;
            RykahMod.reportNote(s, "Rykaah mati (" + deathCause + ") dan auto-respawn dimatikan di config, jadi dia belum hidup lagi. Suami harus memunculkannya.");
            return;
        }
        ServerPlayerEntity owner = brain.owner();
        if (owner == null) return; // tunggu suami online
        if (bot != null) { Bot.kill(s); respawnAt = s.getTicks() + 20; return; } // bersihkan entitas mati dulu
        if (++attempts > 5) {
            awaiting = false;
            RykahMod.reportNote(s, "GAGAL: Rykaah mati dan beberapa kali dicoba dimunculkan lagi tapi tidak berhasil (server mungkin menolak). Dia belum hidup.");
            return;
        }
        Bot.spawnAt(s, owner);
        respawnAt = s.getTicks() + 40;
    }

    private static void finish(MinecraftServer s, Brain brain, ServerPlayerEntity bot) {
        awaiting = false;
        brain.cancelAll();
        AuthHandler.begin(s);
        int now = GameState.countItems(bot);
        int lost = Math.max(0, invBeforeDeath - now);
        lastInvCount = now;
        String note = "Rykaah baru saja mati (penyebab: " + deathCause + ") di koordinat " + deathPos.toShortString()
                + " dan sekarang sudah hidup lagi. Dia dimunculkan ulang oleh mod di dekat suami, bukan di kasur. Kondisi: hp "
                + Math.round(bot.getHealth()) + ", sekitar " + lost + " item hilang (barang jatuh di lokasi kematian; dia belum mengambilnya). "
                + "Tidak ada tugas lama yang dilanjutkan. Sapa suami dengan natural dan tanyakan dia harus ngapain; jangan langsung bertindak.";
        RykahMod.reportNote(s, note);
    }
}
