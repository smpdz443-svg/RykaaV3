package com.example.rykah.mixin;

import com.example.rykah.AuthHandler;
import com.example.rykah.Bot;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Menangkap pesan sistem yang dikirim server ke Rykaah_ (untuk deteksi prompt login/register). */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {
    @Inject(method = "sendMessage(Lnet/minecraft/text/Text;Z)V", at = @At("HEAD"))
    private void rykah$onSystemMessage(Text message, boolean overlay, CallbackInfo ci) {
        if (overlay) return;
        ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;
        if (!Bot.NAME.equals(self.getGameProfile().getName())) return;
        MinecraftServer server = self.getServer();
        if (server == null) return;
        String text = message.getString();
        server.execute(() -> AuthHandler.onSystemMessage(server, self, text));
    }
}
