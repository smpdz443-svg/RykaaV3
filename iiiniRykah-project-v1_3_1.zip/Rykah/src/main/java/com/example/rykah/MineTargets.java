package com.example.rykah;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;

import java.util.List;
import java.util.Locale;
import java.util.function.Predicate;
import java.util.regex.Pattern;

/** Kamus kata (Indonesia/Inggris) ke jenis block untuk mining, menaruh block, dan interaksi. */
public final class MineTargets {
    public record Target(String label, Predicate<BlockState> test, int defaultCount) {}

    private record Entry(Pattern pattern, Target target) {}

    private static Entry e(String regex, String label, Predicate<BlockState> t, int def) {
        return new Entry(Pattern.compile(regex), new Target(label, t, def));
    }

    private static final List<Entry> MINE = List.of(
            e("\\b(batu bara|coal|arang)\\b", "batu bara", s -> s.isIn(BlockTags.COAL_ORES), 8),
            e("\\b(besi|iron)\\b", "bijih besi", s -> s.isIn(BlockTags.IRON_ORES), 8),
            e("\\b(emas|gold)\\b", "bijih emas", s -> s.isIn(BlockTags.GOLD_ORES), 8),
            e("\\b(berlian|diamond)\\b", "bijih berlian", s -> s.isIn(BlockTags.DIAMOND_ORES), 4),
            e("\\b(tembaga|copper)\\b", "bijih tembaga", s -> s.isIn(BlockTags.COPPER_ORES), 8),
            e("\\b(lapis)\\b", "lapis", s -> s.isIn(BlockTags.LAPIS_ORES), 8),
            e("\\b(redstone)\\b", "redstone", s -> s.isIn(BlockTags.REDSTONE_ORES), 8),
            e("\\b(zamrud|emerald)\\b", "zamrud", s -> s.isIn(BlockTags.EMERALD_ORES), 4),
            e("\\b(kayu|pohon|log|wood|tree)\\b", "batang kayu", s -> s.isIn(BlockTags.LOGS), 6),
            e("\\b(batu|stone|cobblestone|cobble)\\b", "batu", s -> s.isOf(Blocks.STONE) || s.isOf(Blocks.COBBLESTONE), 16),
            e("\\b(pasir|sand)\\b", "pasir", s -> s.isOf(Blocks.SAND), 16),
            e("\\b(tanah|dirt)\\b", "tanah", s -> s.isOf(Blocks.DIRT) || s.isOf(Blocks.GRASS_BLOCK), 16),
            e("\\b(kerikil|gravel)\\b", "kerikil", s -> s.isOf(Blocks.GRAVEL), 16)
    );

    private static final List<Entry> USE = List.of(
            e("\\b(pintu|door)\\b", "pintu", s -> s.isIn(BlockTags.DOORS), 1),
            e("\\b(trapdoor|palka)\\b", "trapdoor", s -> s.isIn(BlockTags.TRAPDOORS), 1),
            e("\\b(gerbang|gate)\\b", "gerbang", s -> s.isIn(BlockTags.FENCE_GATES), 1),
            e("\\b(tombol|button)\\b", "tombol", s -> s.isIn(BlockTags.BUTTONS), 1),
            e("\\b(tuas|lever)\\b", "tuas", s -> s.isOf(Blocks.LEVER), 1)
    );

    /** Kata benda -> potongan id item yang dicari di inventori. */
    private static final List<String[]> PLACE = List.of(
            new String[]{"\\b(obor|torch)\\b", "obor", "torch"},
            new String[]{"\\b(cobblestone|cobble|batu)\\b", "batu", "cobblestone"},
            new String[]{"\\b(tanah|dirt)\\b", "tanah", "dirt"},
            new String[]{"\\b(papan|planks|kayu)\\b", "papan kayu", "planks"},
            new String[]{"\\b(kaca|glass)\\b", "kaca", "glass"},
            new String[]{"\\b(pasir|sand)\\b", "pasir", "sand"}
    );

    private MineTargets() {}

    public static Target findMine(String text) { return find(MINE, text); }

    public static Target findUse(String text) { return find(USE, text); }

    private static Target find(List<Entry> list, String text) {
        String t = text.toLowerCase(Locale.ROOT);
        for (Entry en : list) if (en.pattern.matcher(t).find()) return en.target;
        return null;
    }

    /** @return {label, potongan id} atau null. */
    public static String[] findPlace(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        for (String[] p : PLACE) if (Pattern.compile(p[0]).matcher(t).find()) return new String[]{p[1], p[2]};
        return null;
    }

    public static boolean isPlaceable(ItemStack s, String idPart) {
        if (s.isEmpty() || !(s.getItem() instanceof BlockItem)) return false;
        return Registries.ITEM.getId(s.getItem()).getPath().contains(idPart);
    }
}
