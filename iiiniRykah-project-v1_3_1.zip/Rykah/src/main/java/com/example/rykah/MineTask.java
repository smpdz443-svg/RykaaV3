package com.example.rykah;

import net.minecraft.entity.ItemEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Cari block target yang terlihat, jalan ke sana, hancurkan dengan mekanik asli, ambil drop. Menghitung hanya block yang terverifikasi hilang. */
public final class MineTask extends Task {
    private enum Phase { FIND, GO, MINE, COLLECT }

    private final MineTargets.Target target;
    private final int goal;
    private int mined;
    private Phase phase = Phase.FIND;
    private BlockPos current;
    private BlockActions.MiningSession session;
    private final Set<BlockPos> bad = new HashSet<>();
    private int scanCooldown, emptyScans, goTicks, retries, collectUntil, stuckTicks;
    private Vec3d lastPos = Vec3d.ZERO;

    public MineTask(MineTargets.Target target, int goal) {
        this.target = target;
        this.goal = goal;
    }

    @Override public String describe() { return "menghancurkan " + goal + " " + target.label(); }

    @Override public String progress() { return mined + "/" + goal + " " + target.label(); }

    @Override public int maxTicks() { return 20 * 60 * 15; }

    private Status fail(String reason) {
        failReason = reason + " (sudah menghancurkan " + mined + " dari " + goal + " " + target.label() + ")";
        return Status.FAILED;
    }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        switch (phase) {
            case FIND -> {
                if (scanCooldown > 0) { scanCooldown--; return Status.RUNNING; }
                int r = RykahConfig.get().behavior.mineRadius;
                BlockPos p = Scan.nearest(bot, target.test(), r, 8, bad, true);
                if (p == null) {
                    if (emptyScans == 0) brain.debug("scan: tidak ada " + target.label() + " yang terbuka di radius " + r);
                    if (++emptyScans >= 3) return fail("aku nggak menemukan " + target.label() + " yang terlihat dalam radius " + r + " blok");
                    scanCooldown = 40;
                    return Status.RUNNING;
                }
                emptyScans = 0;
                brain.debug("target ketemu di " + p.toShortString() + " (jarak " + Math.round(Math.sqrt(p.getSquaredDistance(bot.getPos()))) + " blok)");
                current = p;
                session = new BlockActions.MiningSession(p);
                phase = Phase.GO;
                goTicks = 0; retries = 0; stuckTicks = 0;
                lastPos = bot.getPos();
            }
            case GO -> {
                if (!target.test().test(bot.getServerWorld().getBlockState(current))) { phase = Phase.FIND; return Status.RUNNING; }
                if (BlockActions.inReach(bot, current) && BlockActions.hasLineOfSight(bot, current)) {
                    Bot.halt(brain.server());
                    phase = Phase.MINE;
                    return Status.RUNNING;
                }
                Nav.walkTo(brain.server(), bot, Vec3d.ofCenter(current), 1.6, false);
                goTicks++;
                if (goTicks % 60 == 0) {
                    stuckTicks = bot.getPos().squaredDistanceTo(lastPos) < 0.25 ? stuckTicks + 1 : 0;
                    lastPos = bot.getPos();
                }
                if (stuckTicks >= 2 || goTicks > 400) {
                    brain.debug("tidak bisa mencapai " + current.toShortString() + " (macet/timeout), cari target lain");
                    bad.add(current); // tidak terjangkau: jangan coba lagi
                    Bot.halt(brain.server());
                    phase = Phase.FIND;
                }
            }
            case MINE -> {
                BlockActions.Result res = session.tick(bot);
                if (res != BlockActions.Result.IN_PROGRESS) brain.debug("hasil mining: " + res);
                switch (res) {
                    case IN_PROGRESS -> { }
                    case DONE -> {
                        mined++;
                        phase = Phase.COLLECT;
                        collectUntil = age + 40;
                    }
                    case GONE -> phase = Phase.FIND;
                    case TOO_FAR, NO_SIGHT -> {
                        session.abort(bot);
                        if (++retries > 5) { bad.add(current); phase = Phase.FIND; } else phase = Phase.GO;
                    }
                    case NO_TOOL -> {
                        session.abort(bot);
                        return fail("aku butuh alat yang cocok di hotbar untuk " + target.label());
                    }
                    case FAILED -> {
                        session.abort(bot);
                        bad.add(current);
                        phase = Phase.FIND;
                    }
                }
            }
            case COLLECT -> {
                List<ItemEntity> items = bot.getServerWorld().getEntitiesByClass(ItemEntity.class,
                        bot.getBoundingBox().expand(8), ItemEntity::isAlive);
                if (items.isEmpty() || age >= collectUntil) {
                    Bot.halt(brain.server());
                    if (mined >= goal) {
                        doneMessage = "Rykaah selesai menghancurkan " + mined + " " + target.label() + " (tiap blok sudah diverifikasi hilang).";
                        return Status.DONE;
                    }
                    phase = Phase.FIND;
                } else {
                    ItemEntity it = items.stream().min(Comparator.comparingDouble(bot::squaredDistanceTo)).get();
                    Nav.walkTo(brain.server(), bot, it.getPos(), 0.6, false);
                }
            }
        }
        return Status.RUNNING;
    }

    @Override
    public void stop(Brain brain, ServerPlayerEntity bot) {
        if (session != null) session.abort(bot);
        Bot.halt(brain.server());
    }
}
