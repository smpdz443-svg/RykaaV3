package com.example.rykah;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Login/register otomatis berdasarkan pesan SISTEM yang diterima Rykaah_ dari server.
 * - Hanya bereaksi pada pesan prompt dalam jendela waktu setelah spawn.
 * - Pesan bergaya chat pemain ("<nama> ...") diabaikan, jadi pemain lain tidak bisa memancing kirim password.
 * - Format perintah (1 atau 2 password) dipilih dari usage yang tertulis di pesan server.
 * - Tiap jenis perintah dibatasi (maxAttemptsPerKind); password salah/registrasi ditutup = berhenti dan lapor.
 */
public final class AuthHandler {
    private enum State { IDLE, WAITING, DONE, FAILED }

    private static final Pattern USAGE = Pattern.compile("/(login|register|l|reg)((?:\\s+[<\\[(][^>\\])\\s]+[>\\])])+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern TOKEN = Pattern.compile("[<\\[(][^>\\])\\s]+[>\\])]");
    private static final Pattern SUCCESS = Pattern.compile("successfully (logged in|registered|authenticated)|logged in successfully|login successful|registration successful|welcome back|berhasil (login|masuk|mendaftar|register|terdaftar)|login berhasil|sukses (login|register)");
    private static final Pattern WRONG_PW = Pattern.compile("(wrong|incorrect|invalid) password|password (is )?(wrong|incorrect|invalid)|password salah|kata sandi salah");
    private static final Pattern REG_CLOSED = Pattern.compile("registration (is )?(disabled|closed)|registrations are (disabled|closed)|pendaftaran (ditutup|dinonaktifkan)");
    private static final Pattern ALREADY = Pattern.compile("already registered|already have an account|sudah terdaftar|sudah (punya|memiliki) akun");
    private static final Pattern NEED_LOGIN = Pattern.compile("/login|please (log ?in|authenticate)|you (need|must) (to )?log ?in|silakan login|silahkan login|harap login|login dulu");
    private static final Pattern NEED_REG = Pattern.compile("/register|/reg |please register|you (need|must) (to )?register|silakan (daftar|register)|silahkan (daftar|register)|daftar dulu|register dulu");
    private static final Pattern CONFIRM_HINT = Pattern.compile("confirm|repeat|twice|again|retype|re-enter|ulangi|konfirmasi");

    private static State state = State.IDLE;
    private static int windowEnd;
    private static int lastSent = -1000;
    private static int loginTries;
    private static int registerTries;
    private static String lastKind = "";

    private AuthHandler() {}

    /** Panggil setiap kali Rykaah_ baru muncul/respawn. */
    public static void begin(MinecraftServer server) {
        state = RykahConfig.get().auth.enabled ? State.WAITING : State.IDLE;
        windowEnd = server.getTicks() + RykahConfig.get().auth.windowTicks;
        lastSent = -1000;
        loginTries = 0;
        registerTries = 0;
        lastKind = "";
    }

    public static void onSystemMessage(MinecraftServer server, ServerPlayerEntity bot, String raw) {
        RykahConfig.Auth cfg = RykahConfig.get().auth;
        if (!cfg.enabled || state != State.WAITING) return;
        if (server.getTicks() > windowEnd) { state = State.IDLE; return; }
        if (raw == null) return;
        String trimmed = raw.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("<") || trimmed.startsWith("[Rykaah")) return; // bukan prompt server
        String t = trimmed.toLowerCase(Locale.ROOT);

        if (SUCCESS.matcher(t).find()) {
            state = State.DONE;
            notifyOwner(server, "Auth berhasil di server.");
            return;
        }
        if (WRONG_PW.matcher(t).find()) {
            state = State.FAILED;
            notifyOwner(server, "Server bilang password salah. Rykaah berhenti mencoba. Cek auth.password di rykah-config.json.");
            return;
        }
        if (REG_CLOSED.matcher(t).find()) {
            state = State.FAILED;
            notifyOwner(server, "Server menutup pendaftaran. Rykaah tidak bisa register otomatis.");
            return;
        }

        boolean wantsLogin = NEED_LOGIN.matcher(t).find();
        boolean wantsReg = NEED_REG.matcher(t).find();
        if (ALREADY.matcher(t).find()) { wantsLogin = true; wantsReg = false; }
        if (!wantsLogin && !wantsReg) return;

        String kind;
        if (wantsLogin && !wantsReg) kind = "login";
        else if (wantsReg && !wantsLogin) kind = "register";
        else kind = loginTries == 0 ? "login" : "register"; // prompt "login atau register": coba login dulu

        int now = server.getTicks();
        if (now - lastSent < cfg.cooldownTicks) return;
        int tries = kind.equals("login") ? loginTries : registerTries;
        if (tries >= cfg.maxAttemptsPerKind) {
            state = State.FAILED;
            notifyOwner(server, "Batas percobaan " + kind + " tercapai tanpa hasil. Rykaah berhenti; metode auth server mungkin tidak didukung.");
            return;
        }

        int args = argCount(kind, trimmed, t);
        String cmd = kind + " " + cfg.password + (args >= 2 ? " " + cfg.password : "");
        if (kind.equals("login")) loginTries++; else registerTries++;
        lastSent = now;
        lastKind = kind;
        RykahMod.LOGGER.info("Auth: kirim /{} ({} argumen password)", kind, Math.max(args, 1));
        server.getCommandManager().executeWithPrefix(bot.getCommandSource(), cmd);
    }

    private static int argCount(String kind, String original, String lower) {
        Matcher m = USAGE.matcher(original);
        while (m.find()) {
            String c = m.group(1).toLowerCase(Locale.ROOT);
            boolean same = kind.equals("login") ? c.startsWith("l") : c.startsWith("reg");
            if (!same) continue;
            Matcher tok = TOKEN.matcher(m.group(2));
            int n = 0;
            while (tok.find()) n++;
            if (n > 0) return Math.min(n, 2);
        }
        if (kind.equals("register") && CONFIRM_HINT.matcher(lower).find()) return 2;
        return 1;
    }

    private static void notifyOwner(MinecraftServer server, String msg) {
        RykahMod.LOGGER.info("Auth: {}", msg);
        RykahMod.tellOwner(server, "[Rykaah_ auth] " + msg);
    }
}
