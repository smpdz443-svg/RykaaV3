package com.example.rykah;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/** Klien Gemini. Kunci: config/gemini-companion-api-key.txt, memori: config/gemini-companion-memory.json (sama seperti versi lama). */
public final class GeminiApiClient {
    private static final Path KEY_FILE = FabricLoader.getInstance().getConfigDir().resolve("gemini-companion-api-key.txt");
    private static final Path MEMORY_FILE = FabricLoader.getInstance().getConfigDir().resolve("gemini-companion-memory.json");
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private static final Object LOCK = new Object();
    private static final List<String[]> HISTORY = new ArrayList<>(); // {role, text}
    private static boolean loaded;

    private GeminiApiClient() {}

    /** @param raw teks asli untuk disimpan di memori; @param prompt teks (dengan konteks) yang dikirim untuk giliran ini. */
    public static String ask(String raw, String prompt) throws Exception {
        String key = readKey();
        String reply;
        synchronized (LOCK) {
            loadHistory();
            List<String[]> contents = new ArrayList<>(HISTORY);
            contents.add(new String[]{"user", prompt});
            RykahConfig.Ai ai = RykahConfig.get().ai;
            try {
                reply = request(ai.primaryModel, key, contents);
            } catch (Exception first) {
                RykahMod.LOGGER.warn("Model utama gagal ({}), coba fallback.", first.toString());
                reply = request(ai.fallbackModel, key, contents);
            }
            if (reply == null || reply.isBlank()) throw new IllegalStateException("Balasan Rykah kosong.");
            HISTORY.add(new String[]{"user", raw});
            HISTORY.add(new String[]{"model", reply});
            while (HISTORY.size() > ai.maxHistoryMessages) HISTORY.remove(0);
            saveHistory();
        }
        return reply.trim();
    }

    private static String readKey() throws Exception {
        if (!Files.exists(KEY_FILE)) throw new IllegalStateException("API Key belum ditemukan: " + KEY_FILE);
        String key = Files.readString(KEY_FILE, StandardCharsets.UTF_8).trim();
        if (key.isEmpty()) throw new IllegalStateException("API Key kosong!");
        return key;
    }

    private static String request(String model, String key, List<String[]> contents) throws Exception {
        RykahConfig.Ai ai = RykahConfig.get().ai;
        JsonObject body = new JsonObject();
        JsonObject sys = new JsonObject();
        JsonArray sysParts = new JsonArray();
        sysParts.add(part(Persona.get()));
        sys.add("parts", sysParts);
        body.add("systemInstruction", sys);
        JsonArray arr = new JsonArray();
        for (String[] m : contents) {
            JsonObject c = new JsonObject();
            c.addProperty("role", m[0]);
            JsonArray parts = new JsonArray();
            parts.add(part(m[1]));
            c.add("parts", parts);
            arr.add(c);
        }
        body.add("contents", arr);
        JsonObject gen = new JsonObject();
        gen.addProperty("temperature", ai.temperature);
        gen.addProperty("maxOutputTokens", ai.maxOutputTokens);
        body.add("generationConfig", gen);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/json")
                .header("x-goog-api-key", key)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (res.statusCode() / 100 != 2) {
            String b = res.body();
            throw new IllegalStateException("Gemini API HTTP " + res.statusCode() + ": " + (b.length() > 200 ? b.substring(0, 200) : b));
        }
        JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
        JsonArray cands = root.has("candidates") ? root.getAsJsonArray("candidates") : null;
        if (cands == null || cands.isEmpty()) throw new IllegalStateException("Gemini tidak memberikan balasan.");
        JsonObject content = cands.get(0).getAsJsonObject().getAsJsonObject("content");
        if (content == null || !content.has("parts")) throw new IllegalStateException("Gemini tidak memberikan balasan.");
        StringBuilder sb = new StringBuilder();
        for (JsonElement p : content.getAsJsonArray("parts")) {
            JsonObject po = p.getAsJsonObject();
            if (po.has("text")) sb.append(po.get("text").getAsString());
        }
        return sb.toString();
    }

    private static JsonObject part(String text) {
        JsonObject o = new JsonObject();
        o.addProperty("text", text);
        return o;
    }

    private static void loadHistory() {
        if (loaded) return;
        loaded = true;
        try {
            if (!Files.exists(MEMORY_FILE)) return;
            JsonArray arr = JsonParser.parseString(Files.readString(MEMORY_FILE, StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement e : arr) {
                JsonObject o = e.getAsJsonObject();
                if (o.has("role") && o.has("text")) HISTORY.add(new String[]{o.get("role").getAsString(), o.get("text").getAsString()});
            }
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Memori gagal dibaca (dimulai kosong): {}", e.toString());
            HISTORY.clear();
        }
    }

    private static void saveHistory() {
        try {
            JsonArray arr = new JsonArray();
            for (String[] m : HISTORY) {
                JsonObject o = new JsonObject();
                o.addProperty("role", m[0]);
                o.addProperty("text", m[1]);
                arr.add(o);
            }
            Path tmp = MEMORY_FILE.resolveSibling(MEMORY_FILE.getFileName() + ".tmp");
            Files.writeString(tmp, arr.toString(), StandardCharsets.UTF_8);
            Files.move(tmp, MEMORY_FILE, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Memori gagal disimpan: {}", e.toString());
        }
    }
}
