package com.example.rykah;

import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Menerjemahkan nama item dari chat (Indonesia/Inggris) ke Item asli di registry. Mengembalikan null bila tidak yakin. */
public final class ItemResolver {
    private static final Map<String, String> WORDS = new LinkedHashMap<>();
    private static final Set<String> FILLER = Set.of("sebuah", "satu", "buah", "dong", "ya", "yang", "aja", "sayang", "suami", "rykah", "rykaah",
            "tolong", "please", "a", "an", "the", "some", "untuk", "ku", "aku", "kamu", "dari", "buat", "bikin", "bikinin", "buatkan", "craft",
            "membuat", "make", "pasang", "gih", "sana", "dulu", "nih", "deh", "lah", "kah");

    static {
        String[][] p = {
                {"pedang", "sword"}, {"kapak", "axe"}, {"beliung", "pickaxe"}, {"sekop", "shovel"}, {"cangkul", "hoe"},
                {"besi", "iron"}, {"emas", "golden"}, {"gold", "golden"}, {"berlian", "diamond"}, {"batu", "stone"}, {"kayu", "wooden"},
                {"netherite", "netherite"}, {"roti", "bread"}, {"papan", "planks"}, {"tongkat", "stick"}, {"obor", "torch"},
                {"tungku", "furnace"}, {"peti", "chest"}, {"perisai", "shield"}, {"busur", "bow"}, {"panah", "arrow"},
                {"helm", "helmet"}, {"baju", "chestplate"}, {"celana", "leggings"}, {"sepatu", "boots"}, {"ember", "bucket"},
                {"pintu", "door"}, {"kaca", "glass"}, {"tangga", "ladder"}, {"kasur", "bed"}, {"meja", "table"},
                {"kerja", "crafting"}, {"crafting", "crafting"}, {"tambang", "pickaxe"}, {"pagar", "fence"}, {"jembatan", "bridge"}
        };
        for (String[] w : p) WORDS.put(w[0], w[1]);
    }

    private ItemResolver() {}

    /** @return item yang dimaksud teks, atau null. Hanya cocok persis dengan id registry (tidak menebak). */
    public static Item find(String text) {
        List<String> toks = new ArrayList<>();
        for (String raw : text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_ ]", " ").split("\\s+")) {
            if (raw.isBlank() || FILLER.contains(raw) || raw.matches("\\d+")) continue;
            toks.add(WORDS.getOrDefault(raw, raw));
        }
        // "crafting table" / "meja kerja" -> crafting_table
        if (toks.contains("table") && toks.contains("crafting")) return Items.CRAFTING_TABLE;
        // coba semua potongan berurutan (n-gram), terpanjang dulu, urutan asli lalu terbalik
        for (int len = Math.min(3, toks.size()); len >= 1; len--) {
            for (int i = 0; i + len <= toks.size(); i++) {
                List<String> sub = toks.subList(i, i + len);
                Item it = lookup(String.join("_", sub));
                if (it == null && len > 1) {
                    List<String> rev = new ArrayList<>(sub);
                    java.util.Collections.reverse(rev);
                    it = lookup(String.join("_", rev));
                }
                if (it != null) return it;
            }
        }
        return null;
    }

    private static Item lookup(String path) {
        Identifier id = Identifier.tryParse("minecraft:" + path);
        if (id == null || !Registries.ITEM.containsId(id)) return null;
        Item it = Registries.ITEM.get(id);
        return it == Items.AIR ? null : it;
    }

    public static String label(Item item) {
        return Registries.ITEM.getId(item).getPath().replace('_', ' ');
    }
}
