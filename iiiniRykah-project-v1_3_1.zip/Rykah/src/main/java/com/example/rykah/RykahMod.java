package com.example.rykah;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

public class RykahMod implements ModInitializer {
    public static final String MOD_ID = "gemini_companion";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static Brain brain;
    private static final Initiative INITIATIVE = new Initiative();

    @Override
    public void onInitialize() {
        RykahConfig.get();
        ServerLifecycleEvents.SERVER_STARTED.register(s -> brain = new Brain(s));
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> brain = null);

        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (brain == null) return;
            Lifecycle.tick(s, brain);
            brain.tick();
            INITIATIVE.tick(s, brain);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> {
            ServerPlayerEntity p = handler.getPlayer();
            if (brain == null || Bot.NAME.equals(p.getGameProfile().getName())) return;
            brain.setOwner(p);
            if (brain.isOwner(p)) Lifecycle.onOwnerJoin(s);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (brain != null && entity instanceof ServerPlayerEntity p && Bot.NAME.equals(p.getGameProfile().getName())) {
                MinecraftServer s = p.getServer();
                if (s != null) Lifecycle.onBotDeath(s, p, source, brain);
            }
        });

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) ->
                onChat(sender, message.getContent().getString().trim()));

        LOGGER.info("Rykaah_ v1.2 siap (badan pemain via Fabric Carpet).");
    }

    private static void onChat(ServerPlayerEntity sender, String text) {
        if (brain == null || text.isEmpty() || Bot.NAME.equals(sender.getGameProfile().getName())) return;
        MinecraftServer server = sender.getServer();
        if (server == null) return;
        brain.setOwner(sender);
        if (!brain.isOwner(sender)) return; // hanya suami yang bisa memerintah/mengobrol
        INITIATIVE.bump(server);
        Intents.Intent intent = Intents.parse(text);
        LOGGER.info("Chat suami: '{}' -> {}", text, intent.kind());
        String note = brain.apply(sender, intent);
        sendToAi(server, sender, text, note);
    }

    private static void sendToAi(MinecraftServer server, ServerPlayerEntity owner, String raw, String note) {
        ServerPlayerEntity bot = Bot.get(server);
        String state = bot != null ? GameState.snapshot(bot, owner, brain.current()) : "tubuh belum muncul";
        StringBuilder prompt = new StringBuilder();
        if (note != null) prompt.append("[Catatan sistem, bukan ucapan suamimu: ").append(note).append("]\n");
        prompt.append("[Kondisi: ").append(state).append("]\n").append(raw);
        String p = prompt.toString();
        CompletableFuture.runAsync(() -> {
            try {
                String reply = GeminiApiClient.ask(raw, p);
                server.execute(() -> say(server, reply));
            } catch (Exception e) {
                server.execute(() -> owner.sendMessage(Text.literal("[Rykaah_ error] " + e.getMessage()), false));
            }
        });
    }

    /** Hasil nyata sebuah aksi/peristiwa (selesai, gagal, mati, respawn) dilaporkan Rykah dengan gayanya sendiri. */
    public static void reportNote(MinecraftServer server, String note) {
        if (brain == null) return;
        ServerPlayerEntity owner = brain.owner();
        if (owner == null) { LOGGER.info("Laporan (suami offline): {}", note); return; }
        ServerPlayerEntity bot = Bot.get(server);
        String state = bot != null ? GameState.snapshot(bot, owner, brain.current()) : "tubuh belum muncul";
        String raw = "(kejadian: " + note + ")";
        String p = "[Catatan sistem, bukan ucapan suamimu: " + note + "]\n[Kondisi: " + state
                + "]\nBeritahu suamimu hal ini dengan gayamu, singkat (1-2 kalimat), sesuai fakta catatan.";
        CompletableFuture.runAsync(() -> {
            try {
                String reply = GeminiApiClient.ask(raw, p);
                server.execute(() -> say(server, reply));
            } catch (Exception e) {
                // AI tidak tersedia: tetap lapor fakta apa adanya.
                server.execute(() -> owner.sendMessage(Text.literal("[Rykaah_] " + note), false));
            }
        });
    }

    public static void say(MinecraftServer server, String text) {
        server.getPlayerManager().broadcast(Text.literal("<" + Bot.NAME + "> " + text), false);
    }

    public static void tellOwner(MinecraftServer server, String text) {
        if (brain == null) return;
        ServerPlayerEntity o = brain.owner();
        if (o != null) o.sendMessage(Text.literal(text), false);
    }
}
