package com.example.rykah;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;

/** Menaruh block dari inventori berjajar ke depan (maks 4 per perintah, semuanya masih dalam jangkauan). Tiap block diverifikasi. */
public final class PlaceTask extends Task {
    public static final int MAX = 4;
    private final String label, idPart;
    private final int count;
    private int placed, fails, cooldown;
    private BlockPos origin;

    public PlaceTask(String label, String idPart, int count) {
        this.label = label;
        this.idPart = idPart;
        this.count = Math.max(1, Math.min(count, MAX));
    }

    @Override public String describe() { return "menaruh " + count + " " + label; }

    @Override public String progress() { return placed + "/" + count; }

    @Override public int maxTicks() { return 20 * 30; }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        if (cooldown-- > 0) return Status.RUNNING;
        cooldown = 5;
        if (origin == null) { Bot.halt(brain.server()); origin = bot.getBlockPos(); }
        if (!hold(bot)) { failReason = "aku tidak punya " + label + " di inventori (baru menaruh " + placed + ")"; return Status.FAILED; }
        BlockPos target = origin.offset(bot.getHorizontalFacing(), placed + fails + 1);
        BlockActions.Result r = BlockActions.placeAt(bot, target);
        if (r == BlockActions.Result.DONE) {
            placed++;
            if (placed >= count) {
                doneMessage = "Rykaah sudah menaruh " + placed + " " + label + " (tiap block terverifikasi ada di dunia).";
                return Status.DONE;
            }
        } else if (++fails >= 2) {
            failReason = "aku tidak bisa menaruh " + label + " di depanku (terhalang atau tidak ada pijakan); berhasil " + placed + " dari " + count;
            return Status.FAILED;
        }
        return Status.RUNNING;
    }

    /** Pastikan block yang dicari ada di tangan; tukar dari inventori utama ke slot hotbar aktif bila perlu. */
    private boolean hold(ServerPlayerEntity bot) {
        PlayerInventory inv = bot.getInventory();
        if (MineTargets.isPlaceable(inv.getStack(inv.selectedSlot), idPart)) return true;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!MineTargets.isPlaceable(s, idPart)) continue;
            if (i < 9) { inv.selectedSlot = i; return true; }
            ItemStack cur = inv.getStack(inv.selectedSlot);
            inv.setStack(inv.selectedSlot, s);
            inv.setStack(i, cur);
            return true;
        }
        return false;
    }
}
