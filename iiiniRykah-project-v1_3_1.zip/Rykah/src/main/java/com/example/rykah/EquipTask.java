package com.example.rykah;

import net.minecraft.server.network.ServerPlayerEntity;

/** Pakai armor terbaik di inventori; hasil diverifikasi dari nilai armor sebelum/sesudah. */
public final class EquipTask extends Task {
    @Override public String describe() { return "memakai armor"; }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        int before = bot.getArmor();
        int changed = Gear.equipBestArmor(bot);
        int after = bot.getArmor();
        if (changed == 0) { failReason = "nggak ada armor yang lebih baik di inventori (armor sekarang " + before + ")"; return Status.FAILED; }
        doneMessage = "Rykaah sudah memakai armor: nilai armor " + before + " -> " + after + " (terverifikasi).";
        return Status.DONE;
    }
}
