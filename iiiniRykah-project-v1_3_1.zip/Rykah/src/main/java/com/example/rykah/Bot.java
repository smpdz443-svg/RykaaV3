package com.example.rykah;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandOutput;
import net.minecraft.text.Text;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;

/** Pembungkus badan pemain Carpet (/player Rykaah_ ...). Gerakan dikirim lewat perintah Carpet, bukan teleport. */
public final class Bot {
    public static final String NAME = "Rykaah_";
    private static String moveState = "";

    /** Menangkap balasan command (mis. error Carpet) ke latest.log supaya bisa didiagnosa. */
    private static final CommandOutput LOG_OUT = new CommandOutput() {
        @Override public void sendMessage(Text message) { RykahMod.LOGGER.info("[cmd-output] {}", message.getString()); }
        @Override public boolean shouldReceiveFeedback() { return true; }
        @Override public boolean shouldTrackOutput() { return true; }
        @Override public boolean shouldBroadcastConsoleToOps() { return false; }
    };

    private Bot() {}

    public static ServerPlayerEntity get(MinecraftServer server) {
        return server.getPlayerManager().getPlayer(NAME);
    }

    public static void exec(MinecraftServer server, String command) {
        try {
            if (RykahConfig.get().behavior.debug) RykahMod.LOGGER.info("[cmd] {}", command);
            ServerCommandSource src = server.getCommandSource().withLevel(4).withOutput(LOG_OUT);
            server.getCommandManager().executeWithPrefix(src, command);
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Command gagal: {} ({})", command, e.toString());
        }
    }

    public static void spawnAt(MinecraftServer server, ServerPlayerEntity owner) {
        try {
            ServerCommandSource src = owner.getCommandSource().withLevel(4).withOutput(LOG_OUT);
            RykahMod.LOGGER.info("Spawn Rykaah_ lewat Carpet di dekat {}", owner.getGameProfile().getName());
            server.getCommandManager().executeWithPrefix(src, "player " + NAME + " spawn");
            moveState = "";
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Spawn gagal: {}", e.toString());
        }
    }

    public static void kill(MinecraftServer server) {
        exec(server, "player " + NAME + " kill");
        moveState = "";
    }

    /** Jalan maju terus (ulang pemanggilan tiap tick aman: perintah hanya dikirim saat status berubah). */
    public static void walk(MinecraftServer server, boolean sprint) {
        String want = sprint ? "sprint" : "walk";
        if (!want.equals(moveState)) {
            exec(server, "player " + NAME + " move forward");
            exec(server, "player " + NAME + (sprint ? " sprint" : " unsprint"));
            moveState = want;
        }
    }

    public static void halt(MinecraftServer server) {
        if (!moveState.isEmpty()) {
            exec(server, "player " + NAME + " stop");
            moveState = "";
        }
    }

    public static void jump(MinecraftServer server) {
        exec(server, "player " + NAME + " jump");
    }
}
