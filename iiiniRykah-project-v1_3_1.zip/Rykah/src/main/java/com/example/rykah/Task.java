package com.example.rykah;

import net.minecraft.server.network.ServerPlayerEntity;

/** Satu tugas bertahap. Hasil dilaporkan hanya berdasarkan status akhir yang diverifikasi tugas itu sendiri. */
public abstract class Task {
    public enum Status { RUNNING, DONE, FAILED }

    public String doneMessage = "Tugas selesai.";
    public String failReason = "Rykaah gagal, suamiku...";
    public int age;

    public abstract String describe();

    public String progress() { return "berjalan " + age / 20 + " detik"; }

    /** Batas waktu (tick) sebelum tugas dianggap gagal. */
    public int maxTicks() { return 20 * 60 * 10; }

    public void start(Brain brain, ServerPlayerEntity bot) {}

    public abstract Status tick(Brain brain, ServerPlayerEntity bot);

    public void stop(Brain brain, ServerPlayerEntity bot) {}
}
