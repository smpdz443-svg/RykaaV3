package com.example.rykah;

import net.minecraft.block.BlockState;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Set;
import java.util.function.Predicate;

/** Pencarian block terdekat di sekitar bot (hanya yang terbuka ke udara, supaya bisa dijangkau tanpa menggali terowongan). */
public final class Scan {
    private Scan() {}

    public static BlockPos nearest(ServerPlayerEntity bot, Predicate<BlockState> test, int radius, int vertical, Set<BlockPos> ignore, boolean mustBeExposed) {
        ServerWorld w = bot.getServerWorld();
        BlockPos c = bot.getBlockPos();
        Vec3d eye = bot.getEyePos();
        BlockPos.Mutable m = new BlockPos.Mutable();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -vertical; dy <= vertical; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    BlockState s = w.getBlockState(m);
                    if (s.isAir() || !test.test(s)) continue;
                    double d = Vec3d.ofCenter(m).squaredDistanceTo(eye);
                    if (d >= bestD) continue;
                    if (ignore != null && ignore.contains(m)) continue;
                    if (mustBeExposed && !exposed(w, m)) continue;
                    best = m.toImmutable();
                    bestD = d;
                }
            }
        }
        return best;
    }

    private static boolean exposed(ServerWorld w, BlockPos p) {
        for (Direction d : Direction.values()) {
            BlockState n = w.getBlockState(p.offset(d));
            if (n.isAir() || (n.isReplaceable() && n.getFluidState().isEmpty())) return true;
        }
        return false;
    }
}
