package com.example.rykah;

import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * Crafting dari resep ASLI server: cek bahan di inventori, konsumsi bahan, taruh hasil di inventori, lalu VERIFIKASI jumlah item.
 * Bahan perantara (papan, tongkat, dll) dibuat otomatis sampai kedalaman 3. Resep 3x3 butuh crafting table dalam jarak 4 blok
 * (Rykah berjalan ke crafting table terdekat dalam radius 24). Bahan mentah yang kurang TIDAK dikarang: tugas gagal dengan alasan jelas.
 */
public final class CraftTask extends Task {
    private static final double TABLE_REACH = 4.0;
    private static final int TABLE_SEARCH = 24;

    private final Item target;
    private final int wanted;
    private int startCount = -1;
    private int cooldown;
    private int steps;

    public CraftTask(Item target, int wanted) {
        this.target = target;
        this.wanted = Math.max(1, Math.min(wanted, 64));
    }

    @Override public String describe() { return "membuat " + wanted + " " + ItemResolver.label(target); }

    @Override public String progress() { return "menyiapkan " + ItemResolver.label(target); }

    @Override public int maxTicks() { return 20 * 90; }

    @Override
    public void start(Brain brain, ServerPlayerEntity bot) { startCount = count(bot, target); }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        int have = count(bot, target) - startCount;
        if (have >= wanted) {
            doneMessage = "Rykaah benar-benar sudah membuat " + have + " " + ItemResolver.label(target) + " (terverifikasi di inventorinya).";
            return Status.DONE;
        }
        if (cooldown > 0) { cooldown--; return Status.RUNNING; }
        if (steps > 80) { failReason = "terlalu banyak langkah crafting tanpa hasil"; return Status.FAILED; }

        String missing = craftOnce(brain, bot, target, 0);
        if (missing == null) { steps++; cooldown = 4; return Status.RUNNING; }
        if (missing.startsWith("#walk")) return Status.RUNNING;
        failReason = missing + " (baru berhasil membuat " + Math.max(0, count(bot, target) - startCount) + " dari " + wanted + ")";
        return Status.FAILED;
    }

    /** @return null bila satu langkah crafting berhasil dijalankan (atau "#walk" bila sedang berjalan ke meja), selain itu alasan gagal. */
    private String craftOnce(Brain brain, ServerPlayerEntity bot, Item item, int depth) {
        List<RecipeEntry<CraftingRecipe>> recipes = bot.getServer().getRecipeManager().listAllOfType(RecipeType.CRAFTING).stream()
                .filter(r -> r.value().getResult(bot.getServerWorld().getRegistryManager()).isOf(item)).toList();
        if (recipes.isEmpty()) return "aku nggak punya resep untuk " + ItemResolver.label(item) + " dan nggak punya bahannya";

        String lastReason = null;
        for (RecipeEntry<CraftingRecipe> entry : recipes) {
            CraftingRecipe r = entry.value();
            List<Ingredient> ings = new ArrayList<>();
            for (Ingredient i : r.getIngredients()) if (!i.isEmpty()) ings.add(i);
            boolean needsTable = ings.size() > 4 || (r instanceof ShapedRecipe s && (s.getWidth() > 2 || s.getHeight() > 2));

            // 1) cek bahan; kalau kurang coba buat bahan perantara
            List<int[]> plan = new ArrayList<>(); // slot yang akan dikonsumsi
            boolean[] used = new boolean[bot.getInventory().size()];
            for (Ingredient ing : ings) {
                int slot = findSlot(bot, ing, used);
                if (slot >= 0) { used[slot] = true; plan.add(new int[]{slot}); continue; }
                if (depth >= 3) { lastReason = "bahan perantara terlalu dalam untuk " + ItemResolver.label(item); plan = null; break; }
                String sub = null;
                for (ItemStack cand : ing.getMatchingStacks()) {
                    if (cand.isEmpty()) continue;
                    String res = craftOnce(brain, bot, cand.getItem(), depth + 1);
                    if (res == null || res.startsWith("#walk")) return res;
                    sub = res;
                }
                lastReason = "kurang bahan: " + describeIngredient(ing) + (sub == null ? "" : " (" + sub + ")");
                plan = null;
                break;
            }
            if (plan == null) continue;

            // 2) meja kerja bila perlu
            if (needsTable) {
                BlockPos table = Scan.nearest(bot, s -> s.isOf(Blocks.CRAFTING_TABLE), TABLE_SEARCH, 6, null, false);
                if (table == null) return "resep ini butuh crafting table dan aku nggak menemukan satu pun dalam radius " + TABLE_SEARCH + " blok";
                if (bot.getEyePos().squaredDistanceTo(net.minecraft.util.math.Vec3d.ofCenter(table)) > TABLE_REACH * TABLE_REACH) {
                    Nav.walkTo(brain.server(), bot, net.minecraft.util.math.Vec3d.ofCenter(table), 2.5, false);
                    return "#walk";
                }
                Bot.halt(brain.server());
            }

            // 3) konsumsi bahan dan berikan hasil, lalu verifikasi
            int before = count(bot, item);
            for (int[] p : plan) {
                ItemStack st = bot.getInventory().getStack(p[0]);
                ItemStack remainder = st.getItem().getRecipeRemainder() == null ? ItemStack.EMPTY : new ItemStack(st.getItem().getRecipeRemainder());
                st.decrement(1);
                if (!remainder.isEmpty()) bot.getInventory().offerOrDrop(remainder);
            }
            ItemStack out = r.getResult(bot.getServerWorld().getRegistryManager()).copy();
            bot.getInventory().offerOrDrop(out);
            if (count(bot, item) <= before) return "hasil crafting " + ItemResolver.label(item) + " tidak masuk inventori (inventori penuh?)";
            return null;
        }
        return lastReason != null ? lastReason : "tidak ada resep yang bisa dipenuhi untuk " + ItemResolver.label(item);
    }

    private static int findSlot(ServerPlayerEntity bot, Ingredient ing, boolean[] used) {
        for (int i = 0; i < bot.getInventory().size(); i++) {
            if (used[i]) continue;
            ItemStack s = bot.getInventory().getStack(i);
            if (s.getCount() > 0 && ing.test(s)) return i;
        }
        return -1;
    }

    private static String describeIngredient(Ingredient ing) {
        ItemStack[] m = ing.getMatchingStacks();
        return m.length == 0 ? "bahan" : ItemResolver.label(m[0].getItem()) + (m.length > 1 ? " (atau sejenisnya)" : "");
    }

    private static int count(ServerPlayerEntity bot, Item item) {
        int n = 0;
        for (int i = 0; i < bot.getInventory().size(); i++) {
            ItemStack s = bot.getInventory().getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    @Override public void stop(Brain brain, ServerPlayerEntity bot) { Bot.halt(brain.server()); }
}
