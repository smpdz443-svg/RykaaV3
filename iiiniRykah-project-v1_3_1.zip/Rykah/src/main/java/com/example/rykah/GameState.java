package com.example.rykah;

import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Ringkasan kondisi game yang ringkas (satu baris) untuk AI, dibuat dari state asli server. */
public final class GameState {
    private static final String[] DIR = {"timur", "tenggara", "selatan", "barat daya", "barat", "barat laut", "utara", "timur laut"};

    private GameState() {}

    public static int countItems(ServerPlayerEntity p) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) n += p.getInventory().getStack(i).getCount();
        return n;
    }

    public static String snapshot(ServerPlayerEntity bot, ServerPlayerEntity owner, Task task) {
        ServerWorld w = bot.getServerWorld();
        StringBuilder sb = new StringBuilder();
        sb.append("pos=").append(bot.getBlockX()).append(',').append(bot.getBlockY()).append(',').append(bot.getBlockZ());
        sb.append(" dim=").append(w.getRegistryKey().getValue().getPath());
        sb.append(" hp=").append(Math.round(bot.getHealth())).append("/").append(Math.round(bot.getMaxHealth()));
        sb.append(" lapar=").append(bot.getHungerManager().getFoodLevel()).append("/20");
        sb.append(" armor=").append(bot.getArmor());
        ItemStack hand = bot.getMainHandStack();
        sb.append(" tangan=").append(hand.isEmpty() ? "kosong" : name(hand));

        Map<String, Integer> counts = new LinkedHashMap<>();
        for (int i = 0; i < bot.getInventory().size(); i++) {
            ItemStack s = bot.getInventory().getStack(i);
            if (!s.isEmpty()) counts.merge(name(s), s.getCount(), Integer::sum);
        }
        sb.append(" inventori=");
        if (counts.isEmpty()) sb.append("kosong");
        else counts.entrySet().stream().sorted((a, b) -> b.getValue() - a.getValue()).limit(8)
                .forEach(e -> sb.append(e.getKey()).append('x').append(e.getValue()).append(' '));

        List<String> eff = new ArrayList<>();
        for (StatusEffectInstance e : bot.getStatusEffects())
            e.getEffectType().getKey().ifPresent(k -> eff.add(k.getValue().getPath()));
        if (!eff.isEmpty()) sb.append(" efek=").append(String.join(",", eff));

        sb.append(w.isThundering() ? " cuaca=badai" : w.isRaining() ? " cuaca=hujan" : " cuaca=cerah");
        long t = w.getTimeOfDay() % 24000L;
        sb.append(t >= 13000 && t < 23000 ? " waktu=malam" : " waktu=siang");

        List<String> posture = new ArrayList<>();
        if (bot.isTouchingWater()) posture.add("berenang");
        if (bot.isClimbing()) posture.add("memanjat");
        if (bot.isFallFlying()) posture.add("terbang elytra");
        else if (!bot.isOnGround() && bot.fallDistance > 3f) posture.add("jatuh");
        if (!posture.isEmpty()) sb.append(" status=").append(String.join(",", posture));

        List<HostileEntity> hostiles = w.getEntitiesByClass(HostileEntity.class, bot.getBoundingBox().expand(16), Entity::isAlive);
        if (!hostiles.isEmpty()) {
            hostiles.sort(Comparator.comparingDouble(bot::squaredDistanceTo));
            sb.append(" monster=");
            for (int i = 0; i < Math.min(3, hostiles.size()); i++) {
                HostileEntity h = hostiles.get(i);
                sb.append(Registries.ENTITY_TYPE.getId(h.getType()).getPath()).append('@')
                        .append(Math.round(bot.distanceTo(h))).append("m ");
            }
        }

        if (owner != null && owner.getWorld() == bot.getWorld()) {
            double dx = owner.getX() - bot.getX(), dz = owner.getZ() - bot.getZ();
            int idx = (int) Math.floorMod(Math.round(Math.toDegrees(Math.atan2(dz, dx)) / 45.0), 8L);
            sb.append(" suami=").append(Math.round(bot.distanceTo(owner))).append("m ke ").append(DIR[idx]);
        } else {
            sb.append(" suami=beda dimensi/offline");
        }
        sb.append(" tugas=").append(task == null ? "tidak ada" : task.describe() + " (" + task.progress() + ")");
        return sb.toString();
    }

    private static String name(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath();
    }
}
