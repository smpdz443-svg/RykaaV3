package com.example.rykah;

import net.minecraft.server.network.ServerPlayerEntity;

/** Mengikuti suami dengan berjalan sungguhan. untilClose=true: selesai begitu sudah dekat ("kemari"). */
public final class FollowTask extends Task {
    private final boolean untilClose;

    public FollowTask(boolean untilClose) {
        this.untilClose = untilClose;
        this.doneMessage = "Rykaah sudah sampai di samping suaminya.";
    }

    @Override public String describe() { return untilClose ? "menghampiri suami" : "mengikuti suami"; }

    @Override public int maxTicks() { return untilClose ? 20 * 120 : Integer.MAX_VALUE; }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        ServerPlayerEntity owner = brain.owner();
        if (owner == null) { failReason = "suami sedang tidak online"; return Status.FAILED; }
        if (owner.getWorld() != bot.getWorld()) {
            if (untilClose) { failReason = "suami ada di dimensi lain"; return Status.FAILED; }
            Bot.halt(brain.server());
            return Status.RUNNING;
        }
        double dist = bot.distanceTo(owner);
        int tp = RykahConfig.get().behavior.followTeleportDistance;
        if (tp > 0 && dist > tp) {
            Bot.exec(brain.server(), "tp " + Bot.NAME + " " + owner.getName().getString());
            return Status.RUNNING;
        }
        boolean arrived = Nav.walkTo(brain.server(), bot, owner.getPos(), 2.5, true);
        return (arrived && untilClose) ? Status.DONE : Status.RUNNING;
    }

    @Override public void stop(Brain brain, ServerPlayerEntity bot) { Bot.halt(brain.server()); }
}
