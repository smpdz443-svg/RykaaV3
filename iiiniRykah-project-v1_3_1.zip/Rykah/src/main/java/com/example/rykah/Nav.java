package com.example.rykah;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Navigasi garis lurus lewat gerakan Carpet (tanpa pathfinding): menghadap target, jalan, lompat saat tertabrak. */
public final class Nav {
    private static int lastJump = -100;

    private Nav() {}

    /** @return true bila sudah dalam jarak horizontal stopDist. */
    public static boolean walkTo(MinecraftServer server, ServerPlayerEntity bot, Vec3d target, double stopDist, boolean sprint) {
        Vec3d pos = bot.getPos();
        double dx = target.x - pos.x, dz = target.z - pos.z;
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d <= stopDist) {
            Bot.halt(server);
            return true;
        }
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        bot.setYaw(yaw);
        bot.setHeadYaw(yaw);
        bot.setPitch(0f);
        Bot.walk(server, sprint && d > 6);
        int now = server.getTicks();
        if ((bot.horizontalCollision || bot.isTouchingWater()) && now - lastJump >= 8) {
            Bot.jump(server);
            lastJump = now;
        }
        return false;
    }
}
