package com.example.rykah;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;

/** Peralatan: pilih senjata terbaik, pakai armor terbaik, dan makan lewat mekanik pemain asli (interactItem). */
public final class Gear {
    private Gear() {}

    private static int weaponScore(ItemStack s) {
        if (s.isEmpty()) return 0;
        String p = Registries.ITEM.getId(s.getItem()).getPath();
        int tier = p.startsWith("netherite") ? 6 : p.startsWith("diamond") ? 5 : p.startsWith("iron") ? 4
                : p.startsWith("stone") ? 3 : p.startsWith("golden") ? 2 : p.startsWith("wooden") ? 1 : 0;
        if (p.endsWith("_sword")) return 10 + tier;
        if (p.endsWith("_axe")) return 5 + tier;
        return 0;
    }

    /** Taruh senjata terbaik di slot hotbar terpilih. @return true bila memegang senjata sungguhan. */
    public static boolean equipBestWeapon(ServerPlayerEntity bot) {
        int best = -1, bestScore = weaponScore(bot.getInventory().getStack(bot.getInventory().selectedSlot));
        if (bestScore > 0) best = bot.getInventory().selectedSlot;
        for (int i = 0; i < bot.getInventory().main.size(); i++) {
            int sc = weaponScore(bot.getInventory().getStack(i));
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        if (best < 0) return false;
        if (best < 9) bot.getInventory().selectedSlot = best;
        else if (best != bot.getInventory().selectedSlot) bot.getInventory().swapSlotWithHotbar(best);
        return true;
    }

    public static boolean isFood(ItemStack s) { return !s.isEmpty() && s.contains(DataComponentTypes.FOOD); }

    /** Mulai makan makanan pertama yang ada. @return true bila proses makan dimulai. */
    public static boolean startEating(ServerPlayerEntity bot) {
        for (int i = 0; i < bot.getInventory().main.size(); i++) {
            ItemStack s = bot.getInventory().getStack(i);
            if (!isFood(s)) continue;
            if (i < 9) bot.getInventory().selectedSlot = i;
            else bot.getInventory().swapSlotWithHotbar(i);
            ItemStack held = bot.getMainHandStack();
            bot.interactionManager.interactItem(bot, bot.getServerWorld(), held, Hand.MAIN_HAND);
            return bot.isUsingItem();
        }
        return false;
    }

    public static int foodCount(ServerPlayerEntity bot) {
        int n = 0;
        for (int i = 0; i < bot.getInventory().size(); i++) if (isFood(bot.getInventory().getStack(i))) n += bot.getInventory().getStack(i).getCount();
        return n;
    }

    /** Pakai armor terbaik dari inventori. @return jumlah slot armor yang diganti/diisi. */
    public static int equipBestArmor(ServerPlayerEntity bot) {
        int changed = 0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            int bestIdx = -1, bestProt = prot(bot.getEquippedStack(slot), slot);
            for (int i = 0; i < bot.getInventory().main.size(); i++) {
                int pr = prot(bot.getInventory().getStack(i), slot);
                if (pr > bestProt) { bestProt = pr; bestIdx = i; }
            }
            if (bestIdx < 0) continue;
            ItemStack cand = bot.getInventory().getStack(bestIdx);
            ItemStack old = bot.getEquippedStack(slot);
            bot.equipStack(slot, cand.copy());
            bot.getInventory().setStack(bestIdx, old.copy());
            changed++;
        }
        return changed;
    }

    private static int prot(ItemStack s, EquipmentSlot slot) {
        if (s.isEmpty() || !(s.getItem() instanceof ArmorItem a) || a.getSlotType() != slot) return -1;
        return a.getProtection();
    }
}
