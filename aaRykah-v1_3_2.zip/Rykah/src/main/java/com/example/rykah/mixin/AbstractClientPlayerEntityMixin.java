package com.example.rykah.mixin;

import com.example.rykah.RykahSkin;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Jalur render langsung: renderer pemain memanggil AbstractClientPlayerEntity.getSkinTextures(). Bila entri daftar pemain belum ada
 * (atau diganti mod lain) renderer jatuh ke skin Steve/Alex bawaan, jadi skin juga dipasang di sini berdasarkan nama profil entitas.
 */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void rykah$skin(CallbackInfoReturnable<SkinTextures> cir) {
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
        SkinTextures s = RykahSkin.forName(self.getGameProfile().getName(), cir.getReturnValue(), "AbstractClientPlayerEntity");
        if (s != null) cir.setReturnValue(s);
    }
}
