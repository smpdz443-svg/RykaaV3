package com.example.rykah;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Memisahkan ucapan Rykah dari baris aksi terstruktur {@code <<ACT {...}>>} yang diputuskan AI dari maksud suami (bahasa apa pun). */
public final class ActionRouter {
    public record Parsed(String text, List<JsonObject> acts) {}

    private static final Pattern ACT = Pattern.compile("<<ACT\\s*(\\{.*?\\})\\s*>>", Pattern.DOTALL);

    private ActionRouter() {}

    public static Parsed parse(String reply) {
        List<JsonObject> acts = new ArrayList<>();
        Matcher m = ACT.matcher(reply);
        while (m.find()) {
            try {
                acts.add(JsonParser.parseString(m.group(1)).getAsJsonObject());
            } catch (Exception e) {
                RykahMod.LOGGER.warn("Aksi AI tidak valid diabaikan: {} ({})", m.group(1), e.toString());
            }
        }
        String text = ACT.matcher(reply).replaceAll("").trim();
        return new Parsed(text, acts);
    }
}
