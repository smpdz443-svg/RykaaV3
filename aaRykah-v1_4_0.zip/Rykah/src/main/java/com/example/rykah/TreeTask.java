package com.example.rykah;

import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Menebang pohon UTUH: mencari batang, mengumpulkan semua log yang tersambung (termasuk cabang dan batang 2x2), memastikan itu pohon alami
 * (ada daun non-buatan, supaya bangunan dari kayu tidak dibongkar), lalu menghancurkan log satu per satu dengan mekanik mining asli.
 * Hanya log yang benar-benar hilang yang dihitung. Log yang terlalu tinggi untuk dijangkau dari tanah dilaporkan jujur.
 */
public final class TreeTask extends Task {
    private enum Phase { FIND, GO, CUT, COLLECT }

    private static final int SEARCH = 20;
    private static final int MAX_LOGS = 220;

    private final int goal;
    private BlockPos hint;
    private Phase phase = Phase.FIND;
    private final List<BlockPos> logs = new ArrayList<>();
    private final Set<BlockPos> bad = new HashSet<>();
    private BlockActions.MiningSession session;
    private BlockPos target;
    private int treesDone, broken, gone, skippedHigh, goTicks, retries, scanCooldown, emptyScans, collectUntil;
    private boolean rejectedNonTree;

    public TreeTask(int goal, BlockPos hint) {
        this.goal = Math.max(1, Math.min(goal, 12));
        this.hint = hint;
    }

    @Override public String describe() { return "menebang " + goal + " pohon"; }

    @Override public String progress() { return treesDone + "/" + goal + " pohon, " + (broken + gone) + " batang"; }

    @Override public int maxTicks() { return 20 * 60 * 10; }

    private Status finish(String reason) {
        failReason = "baru " + treesDone + " dari " + goal + " pohon yang selesai (" + (broken + gone) + " batang): " + reason;
        return Status.FAILED;
    }

    private static boolean isLog(ServerWorld w, BlockPos p) { return w.getBlockState(p).isIn(BlockTags.LOGS); }

    private List<BlockPos> flood(ServerWorld w, BlockPos start) {
        List<BlockPos> out = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> q = new ArrayDeque<>();
        q.add(start);
        seen.add(start);
        while (!q.isEmpty() && out.size() < MAX_LOGS) {
            BlockPos c = q.poll();
            out.add(c);
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                BlockPos n = c.add(dx, dy, dz);
                if (seen.contains(n)) continue;
                if (Math.abs(n.getX() - start.getX()) > 8 || Math.abs(n.getZ() - start.getZ()) > 8) continue;
                if (n.getY() < start.getY() - 3 || n.getY() > start.getY() + 30) continue;
                if (!isLog(w, n)) continue;
                seen.add(n);
                q.add(n);
            }
        }
        return out;
    }

    private boolean natural(ServerWorld w, List<BlockPos> tree) {
        for (BlockPos p : tree) {
            for (int dx = -2; dx <= 2; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) {
                BlockState s = w.getBlockState(p.add(dx, dy, dz));
                if (s.isIn(BlockTags.LEAVES) && s.contains(LeavesBlock.PERSISTENT) && !s.get(LeavesBlock.PERSISTENT)) return true;
            }
        }
        return false;
    }

    private void treeFinished() {
        treesDone++;
        logs.clear();
        phase = Phase.COLLECT;
        collectUntil = age + 80;
    }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        ServerWorld w = bot.getServerWorld();
        switch (phase) {
            case FIND -> {
                BlockPos start = null;
                if (hint != null) {
                    if (isLog(w, hint)) start = hint;
                    hint = null;
                }
                if (start == null) {
                    if (scanCooldown > 0) { scanCooldown--; return Status.RUNNING; }
                    start = Scan.nearest(bot, s -> s.isIn(BlockTags.LOGS), SEARCH, 10, bad, false);
                }
                if (start == null) {
                    if (++emptyScans >= 3) return finish(rejectedNonTree
                            ? "yang kutemukan sepertinya bukan pohon alami (mungkin bangunan kayu), jadi nggak kutebang"
                            : "aku nggak menemukan pohon dalam radius " + SEARCH + " blok");
                    scanCooldown = 40;
                    return Status.RUNNING;
                }
                emptyScans = 0;
                List<BlockPos> tree = flood(w, start);
                if (!natural(w, tree)) {
                    rejectedNonTree = true;
                    bad.addAll(tree);
                    return Status.RUNNING;
                }
                logs.clear();
                logs.addAll(tree);
                phase = Phase.GO;
                goTicks = 0;
                retries = 0;
            }
            case GO -> {
                int before = logs.size();
                logs.removeIf(p -> !isLog(w, p));
                gone += before - logs.size(); // hilang sendiri (mis. mod pohon tumbang)
                if (logs.isEmpty()) { treeFinished(); return Status.RUNNING; }
                Vec3d eye = bot.getEyePos();
                target = logs.stream().min(Comparator.comparingDouble(p -> Vec3d.ofCenter(p).squaredDistanceTo(eye))).get();
                if (BlockActions.inReach(bot, target) && BlockActions.hasLineOfSight(bot, target)) {
                    Bot.halt(brain.server());
                    session = new BlockActions.MiningSession(target);
                    phase = Phase.CUT;
                    return Status.RUNNING;
                }
                double hd = Math.hypot(target.getX() + 0.5 - bot.getX(), target.getZ() + 0.5 - bot.getZ());
                if (target.getY() - bot.getBlockY() > 4 && hd < 2.5) {
                    logs.remove(target);
                    skippedHigh++;
                    return Status.RUNNING;
                }
                Nav.walkTo(brain.server(), bot, Vec3d.ofCenter(target), 1.8, false);
                if (++goTicks > 300) {
                    bad.add(target);
                    logs.remove(target);
                    skippedHigh++;
                    goTicks = 0;
                    Bot.halt(brain.server());
                }
            }
            case CUT -> {
                BlockActions.Result res = session.tick(bot);
                switch (res) {
                    case IN_PROGRESS -> { }
                    case DONE -> { broken++; logs.remove(target); phase = Phase.GO; goTicks = 0; retries = 0; }
                    case GONE -> { gone++; logs.remove(target); phase = Phase.GO; }
                    case TOO_FAR, NO_SIGHT -> {
                        session.abort(bot);
                        if (++retries > 5) { logs.remove(target); skippedHigh++; retries = 0; }
                        phase = Phase.GO;
                    }
                    case NO_TOOL, FAILED -> {
                        session.abort(bot);
                        logs.remove(target);
                        skippedHigh++;
                        phase = Phase.GO;
                    }
                }
            }
            case COLLECT -> {
                List<ItemEntity> items = w.getEntitiesByClass(ItemEntity.class, bot.getBoundingBox().expand(10), ItemEntity::isAlive);
                if (items.isEmpty() || age >= collectUntil) {
                    Bot.halt(brain.server());
                    if (treesDone >= goal) {
                        doneMessage = "Rykaah selesai menebang " + treesDone + " pohon (" + (broken + gone) + " batang hilang, terverifikasi)"
                                + (skippedHigh > 0 ? "; " + skippedHigh + " batang atas tidak terjangkau" : "") + ".";
                        return Status.DONE;
                    }
                    phase = Phase.FIND;
                } else {
                    ItemEntity it = items.stream().min(Comparator.comparingDouble(bot::squaredDistanceTo)).get();
                    Nav.walkTo(brain.server(), bot, it.getPos(), 0.6, false);
                }
            }
        }
        return Status.RUNNING;
    }

    @Override
    public void stop(Brain brain, ServerPlayerEntity bot) {
        if (session != null) session.abort(bot);
        Bot.halt(brain.server());
    }
}
