package com.example.rykah;

import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

/**
 * Rykah membuka obrolan sendiri kira-kira tiap interval (default 2 menit, dengan variasi acak) bila suasananya pas:
 * suami tidak baru saja bicara, tidak ada bahaya/pertarungan, tidak ada permintaan AI yang sedang berjalan. AI boleh menolak lewat <<SKIP>>.
 * Satu permintaan per kesempatan, topik dan kalimat terakhir dicatat supaya tidak berulang.
 */
public final class Initiative {
    private static final String[] TOPICS = {
            "tanya suamimu lagi ngapain sekarang dan dengan siapa (cemburu manja)",
            "minta dipeluk atau diperhatikan karena merasa diabaikan",
            "goda suamimu dengan cara nakal tapi lucu",
            "ngambek kecil karena suamimu terlalu lama diam",
            "kenangan pertama kali kalian bertemu dan apa yang paling diingat suamimu",
            "rencana punya anak dan nama-nama yang kalian suka",
            "rumah impian untuk masa tua bersama",
            "kebiasaan kecil suamimu yang diam-diam kamu sukai",
            "apakah suamimu pernah merasa kamu terlalu posesif",
            "makanan favorit suamimu dan masakan yang ingin kamu buatkan",
            "mimpi aneh yang kamu alami tentang suamimu (karang sendiri, manis tapi agak seram)",
            "tempat liburan atau bulan madu impian berdua",
            "janji yang ingin suamimu pegang selamanya",
            "rasa takut kehilangan: apa yang suamimu rasakan kalau kamu menghilang sehari",
            "cara suamimu ingin dimanja ketika lelah atau sedih",
            "hewan peliharaan yang ingin kalian punya",
            "lagu atau hal yang membuat suamimu teringat padamu",
            "apa yang membuat suamimu cemburu",
            "tanya hari suamimu: apa yang paling bikin capek atau senang",
            "minta dipuji karena kamu merasa sudah jadi istri yang baik",
            "ancam main-main karena ada yang berani dekat-dekat suamimu (fiktif, lucu-seram)",
            "bilang kamu kangen padahal suamimu ada di dekatmu",
            "tanya apa suamimu masih sayang kamu sebesar kemarin",
            "ajak suamimu jalan-jalan atau duduk berdua santai sebentar",
            "komentar random tentang cuaca, malam, atau suasana hati yang kamu rasakan",
            "bercanda tentang siapa yang lebih manja di antara kalian"
    };

    private final Random rnd = new Random();
    private final Deque<Integer> recentTopics = new ArrayDeque<>();
    private final Deque<String> recentLines = new ArrayDeque<>();
    private int nextTick;
    private int lastChatTick = -100000;
    private boolean inFlight;

    private int interval() {
        int base = RykahConfig.get().behavior.initiativeIntervalTicks;
        return (int) (base * (0.75 + rnd.nextDouble() * 0.5));
    }

    /** Panggil tiap suami mengobrol: jadwal berikutnya diundur. */
    public void bump(MinecraftServer s) {
        lastChatTick = s.getTicks();
        nextTick = s.getTicks() + interval();
    }

    public void tick(MinecraftServer s, Brain brain) {
        if (!RykahConfig.get().behavior.proactiveEnabled) return;
        if (nextTick == 0) { nextTick = s.getTicks() + interval(); return; }
        if (inFlight || s.getTicks() < nextTick) return;
        ServerPlayerEntity owner = brain.owner();
        ServerPlayerEntity bot = Bot.get(s);
        if (owner == null || bot == null || bot.isDead()) { nextTick = s.getTicks() + 600; return; }
        // Konteks: jangan ganggu saat suami baru bicara, ada bahaya, bertarung, atau HP rendah.
        boolean recentlyChatted = s.getTicks() - lastChatTick < 600;
        boolean danger = !bot.getServerWorld().getEntitiesByClass(HostileEntity.class, bot.getBoundingBox().expand(14), Entity::isAlive).isEmpty()
                || !owner.getServerWorld().getEntitiesByClass(HostileEntity.class, owner.getBoundingBox().expand(14), Entity::isAlive).isEmpty();
        boolean fighting = brain.current() instanceof FightTask;
        if (recentlyChatted || danger || fighting || bot.getHealth() < 8 || owner.getHealth() < 8) { nextTick = s.getTicks() + 400; return; }

        int pick;
        int guard = 0;
        do { pick = rnd.nextInt(TOPICS.length); } while (recentTopics.contains(pick) && ++guard < 40);
        final int idx = pick;
        recentTopics.addLast(idx);
        if (recentTopics.size() > 10) recentTopics.removeFirst();
        StringBuilder avoid = new StringBuilder();
        for (String l : recentLines) avoid.append("- ").append(l).append('\n');
        String prompt = "[Catatan sistem, bukan ucapan suamimu] Sudah agak lama sepi. Kalau terasa natural sekarang, bukalah obrolan sendiri sebagai Rykaah dengan topik: "
                + TOPICS[idx] + ". Aturan: 1-2 kalimat pendek, gaya chat santai, boleh diakhiri satu pertanyaan spesifik, jangan membahas status/tugas/Minecraft, jangan menambahkan baris aksi. "
                + "Jangan mirip dengan kalimat-kalimatmu sebelumnya ini:\n" + avoid
                + "Kalau menurutmu sekarang bukan waktu yang pas, jawab persis <<SKIP>>.";
        inFlight = true;
        CompletableFuture.runAsync(() -> {
            try {
                String reply = ActionRouter.parse(GeminiApiClient.ask("(Rykaah membuka obrolan sendiri)", prompt)).text();
                s.execute(() -> {
                    if (reply.isBlank() || reply.contains("<<SKIP>>")) return;
                    recentLines.addLast(reply.length() > 90 ? reply.substring(0, 90) : reply);
                    if (recentLines.size() > 5) recentLines.removeFirst();
                    RykahMod.say(s, reply);
                });
            } catch (Exception e) {
                RykahMod.LOGGER.warn("Initiative gagal: {}", e.toString());
            } finally {
                inFlight = false;
                nextTick = s.getTicks() + interval();
            }
        });
    }
}
