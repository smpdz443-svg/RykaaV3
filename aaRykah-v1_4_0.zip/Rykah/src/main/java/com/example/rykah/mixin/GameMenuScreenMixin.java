package com.example.rykah.mixin;

import com.example.rykah.RykahStatusScreen;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Menambah tombol "Status Rykah" di menu jeda: tepat di bawah tombol Video Settings bila ada, selain itu di bawah tombol paling bawah. */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {
    protected GameMenuScreenMixin(Text title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void rykah$addStatusButton(CallbackInfo ci) {
        ClickableWidget video = null;
        int maxBottom = 0;
        for (Element e : this.children()) {
            if (!(e instanceof ClickableWidget cw)) continue;
            maxBottom = Math.max(maxBottom, cw.getY() + cw.getHeight());
            if (cw.getMessage().getContent() instanceof TranslatableTextContent t && "options.video".equals(t.getKey())) video = cw;
        }
        int w = video != null ? video.getWidth() : 204;
        int x = video != null ? video.getX() : this.width / 2 - 102;
        int y = video != null ? video.getY() + video.getHeight() + 4 : maxBottom + 4;
        if (y + 20 > this.height) { x = 4; y = 4; w = 110; }
        Screen self = this;
        addDrawableChild(ButtonWidget.builder(Text.literal("Status Rykah"),
                b -> { if (this.client != null) this.client.setScreen(new RykahStatusScreen(self)); })
                .dimensions(x, y, w, 20).build());
    }
}
