package com.example.rykah;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;

/**
 * Memakai perlengkapan lewat slot asli. Tanpa nama item: armor terbaik di inventori. Dengan nama item: armor/elytra ke slotnya, perisai ke tangan kiri,
 * alat/senjata ke tangan utama; bila item tergeletak di dekat (diberikan suami) dia mengambilnya dulu. Hasil diverifikasi dari slot yang terisi.
 */
public final class EquipTask extends Task {
    private final String itemText;
    private Item want;
    private boolean resolved;
    private int walkTicks;

    public EquipTask() { this(null); }

    public EquipTask(String itemText) { this.itemText = itemText; }

    @Override public String describe() { return "memakai " + (itemText == null ? "armor terbaik" : itemText); }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        if (!resolved) {
            resolved = true;
            if (itemText != null) want = ItemResolver.find(itemText);
        }
        if (want == null) {
            if (itemText != null && !itemText.toLowerCase().contains("armor") && !itemText.toLowerCase().contains("baju")) {
                failReason = "aku belum ngerti item yang dimaksud (" + itemText + ")";
                return Status.FAILED;
            }
            int before = bot.getArmor();
            int changed = Gear.equipBestArmor(bot);
            int after = bot.getArmor();
            if (changed == 0) { failReason = "nggak ada armor yang lebih bagus di inventoriku (armor sekarang " + before + ")"; return Status.FAILED; }
            doneMessage = "Rykaah sudah memakai armor: nilai armor " + before + " -> " + after + " (terverifikasi).";
            return Status.DONE;
        }
        if (isEquipped(bot)) { doneMessage = "Rykaah sudah memakai " + ItemResolver.label(want) + "."; return Status.DONE; }
        int slot = -1;
        for (int i = 0; i < bot.getInventory().main.size(); i++) {
            if (bot.getInventory().getStack(i).isOf(want)) { slot = i; break; }
        }
        if (slot < 0) {
            List<ItemEntity> items = bot.getServerWorld().getEntitiesByClass(ItemEntity.class, bot.getBoundingBox().expand(10),
                    e -> e.isAlive() && e.getStack().isOf(want));
            if (items.isEmpty()) { failReason = "aku nggak punya " + ItemResolver.label(want) + " dan nggak ada yang tergeletak di dekatku"; return Status.FAILED; }
            if (++walkTicks > 200) { failReason = "aku nggak bisa menjangkau " + ItemResolver.label(want) + " yang jatuh"; return Status.FAILED; }
            Nav.walkTo(brain.server(), bot, items.get(0).getPos(), 0.5, false);
            return Status.RUNNING;
        }
        Bot.halt(brain.server());
        ItemStack st = bot.getInventory().getStack(slot);
        EquipmentSlot es = null;
        if (st.getItem() instanceof ArmorItem a) es = a.getSlotType();
        else if (st.isOf(Items.ELYTRA)) es = EquipmentSlot.CHEST;
        else if (st.isOf(Items.SHIELD)) es = EquipmentSlot.OFFHAND;
        if (es != null) {
            ItemStack old = bot.getEquippedStack(es).copy();
            bot.equipStack(es, st.copy());
            bot.getInventory().setStack(slot, old);
        } else if (slot < 9) {
            bot.getInventory().selectedSlot = slot;
        } else {
            bot.getInventory().swapSlotWithHotbar(slot);
        }
        if (isEquipped(bot)) { doneMessage = "Rykaah sudah memakai " + ItemResolver.label(want) + " (terverifikasi)."; return Status.DONE; }
        failReason = "aku sudah coba memakai " + ItemResolver.label(want) + " tapi slotnya tidak berubah";
        return Status.FAILED;
    }

    private boolean isEquipped(ServerPlayerEntity bot) {
        if (bot.getMainHandStack().isOf(want) || bot.getOffHandStack().isOf(want)) return true;
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET})
            if (bot.getEquippedStack(s).isOf(want)) return true;
        return false;
    }
}
