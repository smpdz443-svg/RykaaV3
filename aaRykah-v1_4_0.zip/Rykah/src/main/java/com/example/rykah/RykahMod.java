package com.example.rykah;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class RykahMod implements ModInitializer {
    public static final String MOD_ID = "gemini_companion";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static Brain brain;
    private static final Initiative INITIATIVE = new Initiative();
    private static volatile List<String> status = List.of("Rykah belum muncul.");

    /** Ringkasan status untuk layar status di menu jeda (diperbarui server tiap detik). */
    public static List<String> status() { return status; }

    @Override
    public void onInitialize() {
        RykahConfig.get();
        ServerLifecycleEvents.SERVER_STARTED.register(s -> brain = new Brain(s));
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> brain = null);

        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (brain == null) return;
            Lifecycle.tick(s, brain);
            brain.tick();
            INITIATIVE.tick(s, brain);
            if (s.getTicks() % 20 == 0) refreshStatus(s);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> {
            ServerPlayerEntity p = handler.getPlayer();
            if (brain == null || Bot.NAME.equalsIgnoreCase(p.getGameProfile().getName())) return;
            brain.setOwner(p);
            if (brain.isOwner(p)) Lifecycle.onOwnerJoin(s);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (brain != null && entity instanceof ServerPlayerEntity p && Bot.NAME.equalsIgnoreCase(p.getGameProfile().getName())) {
                MinecraftServer s = p.getServer();
                if (s != null) Lifecycle.onBotDeath(s, p, source, brain);
            }
        });

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) ->
                onChat(sender, message.getContent().getString().trim()));

        LOGGER.info("Rykaah_ v1.2 siap (badan pemain via Fabric Carpet).");
    }

    private static void refreshStatus(MinecraftServer s) {
        if (brain == null) return;
        ServerPlayerEntity bot = Bot.get(s);
        status = bot == null ? List.of("Tubuh Rykah belum muncul.") : GameState.statusLines(bot, brain.owner(), brain.current());
    }

    private static void onChat(ServerPlayerEntity sender, String text) {
        if (brain == null || text.isEmpty() || Bot.NAME.equalsIgnoreCase(sender.getGameProfile().getName())) return;
        MinecraftServer server = sender.getServer();
        if (server == null) return;
        brain.setOwner(sender);
        if (!brain.isOwner(sender)) return; // hanya suami yang bisa memerintah/mengobrol
        INITIATIVE.bump(server);
        Intents.Intent quick = Intents.parse(text);
        // Hanya perintah berhenti yang dijalankan seketika (tanpa menunggu AI); sisanya dipahami AI dari maksud suami.
        if (quick.kind() == Intents.Kind.STOP) brain.cancelAll();
        LOGGER.info("Chat suami: '{}'", text);
        sendToAi(server, sender, text, quick);
    }

    private static void sendToAi(MinecraftServer server, ServerPlayerEntity owner, String raw, Intents.Intent fallback) {
        ServerPlayerEntity bot = Bot.get(server);
        String state = bot != null ? GameState.snapshot(bot, owner, brain.current()) : "tubuh belum muncul";
        String last = brain.lastActionDesc();
        String p = "[Konteks pribadi untukmu, JANGAN dibacakan ke suami: " + state + " | " + GameState.ownerContext(owner)
                + (last == null ? "" : " | tugas_terakhir=" + last) + "]\n" + raw;
        CompletableFuture.runAsync(() -> {
            try {
                String reply = GeminiApiClient.ask(raw, p);
                server.execute(() -> handleReply(server, reply));
            } catch (Exception e) {
                server.execute(() -> {
                    owner.sendMessage(Text.literal("[Rykaah_ error] " + e.getMessage()), false);
                    // AI tidak tersedia: perintah yang jelas tetap dijalankan lewat pengenal sederhana.
                    if (brain != null && fallback.kind() != Intents.Kind.CHAT) brain.apply(owner, fallback);
                });
            }
        });
    }

    private static void handleReply(MinecraftServer server, String reply) {
        ActionRouter.Parsed parsed = ActionRouter.parse(reply);
        if (!parsed.text().isBlank()) say(server, parsed.text());
        if (brain == null || parsed.acts().isEmpty()) return;
        String err = brain.applyActions(parsed.acts());
        if (err != null) reportNote(server, err);
    }

    /** Hasil nyata sebuah aksi/peristiwa (selesai, gagal, mati, respawn) dilaporkan Rykah dengan gayanya sendiri. */
    public static void reportNote(MinecraftServer server, String note) {
        if (brain == null) return;
        ServerPlayerEntity owner = brain.owner();
        if (owner == null) { LOGGER.info("Laporan (suami offline): {}", note); return; }
        ServerPlayerEntity bot = Bot.get(server);
        String state = bot != null ? GameState.snapshot(bot, owner, brain.current()) : "tubuh belum muncul";
        String raw = "(kejadian: " + note + ")";
        String p = "[Catatan sistem, bukan ucapan suamimu: " + note + "]\n[Konteks pribadi, jangan dibacakan: " + state
                + "]\nKabari suamimu hal ini dengan gayamu sendiri: SATU kalimat pendek yang natural, tanpa angka teknis, koordinat, atau istilah sistem, dan jangan berpura-pura sudah berhasil. Jangan menambahkan baris aksi.";
        CompletableFuture.runAsync(() -> {
            try {
                String reply = ActionRouter.parse(GeminiApiClient.ask(raw, p)).text();
                server.execute(() -> say(server, reply));
            } catch (Exception e) {
                // AI tidak tersedia: tetap lapor fakta apa adanya.
                server.execute(() -> owner.sendMessage(Text.literal("[Rykaah_] " + note), false));
            }
        });
    }

    public static void say(MinecraftServer server, String text) {
        if (text == null || text.isBlank()) return;
        server.getPlayerManager().broadcast(Text.literal("<" + Bot.NAME + "> " + text), false);
    }

    public static void tellOwner(MinecraftServer server, String text) {
        if (brain == null) return;
        ServerPlayerEntity o = brain.owner();
        if (o != null) o.sendMessage(Text.literal(text), false);
    }
}
