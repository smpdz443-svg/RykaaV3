package com.example.rykah;

import net.minecraft.entity.ItemEntity;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Comparator;
import java.util.List;

/** Mengambil item yang tergeletak di sekitar dengan berjalan ke sana (pickup asli). Selesai bila tidak ada item lagi. */
public final class CollectTask extends Task {
    private int before = -1, stuck;

    @Override public String describe() { return "mengambil item di sekitar"; }

    @Override public int maxTicks() { return 20 * 45; }

    @Override
    public Status tick(Brain brain, ServerPlayerEntity bot) {
        if (before < 0) before = GameState.countItems(bot);
        List<ItemEntity> items = bot.getServerWorld().getEntitiesByClass(ItemEntity.class, bot.getBoundingBox().expand(20), ItemEntity::isAlive);
        if (items.isEmpty()) {
            Bot.halt(brain.server());
            doneMessage = "Rykaah mengambil item di sekitar (" + Math.max(0, GameState.countItems(bot) - before) + " buah masuk inventori).";
            return Status.DONE;
        }
        ItemEntity it = items.stream().min(Comparator.comparingDouble(bot::squaredDistanceTo)).get();
        if (++stuck > 400) { failReason = "ada item yang nggak bisa kujangkau"; return Status.FAILED; }
        Nav.walkTo(brain.server(), bot, it.getPos(), 0.5, false);
        return Status.RUNNING;
    }

    @Override public void stop(Brain brain, ServerPlayerEntity bot) { Bot.halt(brain.server()); }
}
