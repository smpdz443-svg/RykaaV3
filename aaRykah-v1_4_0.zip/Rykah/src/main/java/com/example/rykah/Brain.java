package com.example.rykah;

import com.google.gson.JsonObject;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Penjadwal tugas: menjalankan, memberi batas waktu, menangkap error, membatalkan, dan melaporkan hasil yang terverifikasi. */
public final class Brain {
    private final MinecraftServer server;
    private UUID ownerId;
    private Task current;
    private boolean started;
    private final Deque<Task> queue = new ArrayDeque<>();
    private JsonObject lastAction;
    private String lastActionDesc;

    public Brain(MinecraftServer server) { this.server = server; }

    public MinecraftServer server() { return server; }

    public void setOwner(ServerPlayerEntity p) {
        String name = p.getGameProfile().getName();
        if (Bot.NAME.equalsIgnoreCase(name)) return;
        String locked = RykahConfig.get().behavior.ownerName;
        if (!locked.isBlank() && !locked.equalsIgnoreCase(name)) return;
        if (ownerId == null || owner() == null) ownerId = p.getUuid();
    }

    public ServerPlayerEntity owner() {
        return ownerId == null ? null : server.getPlayerManager().getPlayer(ownerId);
    }

    public boolean isOwner(ServerPlayerEntity p) { return p.getUuid().equals(ownerId); }

    public Task current() { return current; }

    /** Log + (bila debug aktif) pesan diagnosa ke chat suami. */
    public void debug(String msg) {
        RykahMod.LOGGER.info("[debug] {}", msg);
        if (RykahConfig.get().behavior.debug) RykahMod.tellOwner(server, "[Rykaah_ debug] " + msg);
    }

    public void cancelAll() {
        ServerPlayerEntity bot = Bot.get(server);
        if (current != null && bot != null) safeStop(current, bot);
        current = null;
        started = false;
        queue.clear();
        Bot.halt(server);
    }

    private void safeStop(Task t, ServerPlayerEntity bot) {
        try { t.stop(this, bot); } catch (Exception e) { RykahMod.LOGGER.warn("Task.stop error: {}", e.toString()); }
    }


    public String lastActionDesc() { return lastActionDesc; }

    private static String str(JsonObject a, String k) {
        try { return a.has(k) && !a.get(k).isJsonNull() ? a.get(k).getAsString().trim() : ""; } catch (Exception e) { return ""; }
    }

    private static int num(JsonObject a, String k, int def) {
        try { return a.has(k) ? Math.max(1, Math.min(256, a.get(k).getAsInt())) : def; } catch (Exception e) { return def; }
    }

    private static boolean flag(JsonObject a, String k) {
        try { return a.has(k) && a.get(k).getAsBoolean(); } catch (Exception e) { return false; }
    }

    /** Menjalankan aksi hasil pemahaman AI. Aksi kedua dst. diantrikan setelah yang pertama. @return alasan penolakan (untuk dikabarkan natural) atau null. */
    public String applyActions(List<JsonObject> acts) {
        String err = null;
        for (int i = 0; i < acts.size() && i < 4; i++) {
            String r = applyAction(acts.get(i), i > 0);
            if (r != null && err == null) err = r;
        }
        return err;
    }

    private String applyAction(JsonObject a, boolean append) {
        String d = str(a, "do").toLowerCase(Locale.ROOT);
        debug("aksi dari AI: " + a);
        if (d.equals("stop") || d.equals("stay")) { cancelAll(); return null; }
        ServerPlayerEntity bot = Bot.get(server);
        if (bot == null || bot.isDead()) return "badan Rykaah belum muncul atau sedang mati, jadi dia belum bisa melakukan apa pun";
        JsonObject src = a;
        if (d.equals("resume")) {
            if (lastAction == null) return "tidak ada tugas sebelumnya yang bisa diteruskan";
            src = lastAction;
            d = str(src, "do").toLowerCase(Locale.ROOT);
        }
        Task t;
        try {
            t = build(d, src);
        } catch (IllegalArgumentException e) {
            return e.getMessage();
        }
        if (t == null) return "Rykaah belum bisa melakukan hal itu (aksi '" + d + "' belum didukung)";
        if (append) queue.add(t); else set(t);
        lastAction = src.deepCopy();
        lastActionDesc = t.describe();
        return null;
    }

    private Task build(String d, JsonObject a) {
        switch (d) {
            case "follow": return new FollowTask(false);
            case "come": return new FollowTask(true);
            case "mine": {
                String what = str(a, "target");
                MineTargets.Target t = MineTargets.findMine(what);
                if (t == null) throw new IllegalArgumentException("Rykaah belum tahu cara mencari '" + what + "'");
                return new MineTask(t, num(a, "count", t.defaultCount()));
            }
            case "chop": {
                ServerPlayerEntity o = owner();
                net.minecraft.util.math.BlockPos hint = null;
                if (flag(a, "looked") && o != null) {
                    try {
                        net.minecraft.util.hit.HitResult hit = o.raycast(24.0, 1.0f, false);
                        if (hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) hint = ((net.minecraft.util.hit.BlockHitResult) hit).getBlockPos();
                    } catch (Exception ignored) { /* tanpa petunjuk */ }
                }
                return new TreeTask(num(a, "count", 1), hint);
            }
            case "craft": {
                String what = str(a, "item");
                net.minecraft.item.Item it = ItemResolver.find(what);
                if (it == null) throw new IllegalArgumentException("Rykaah belum paham item '" + what + "' yang harus dibuat");
                return new CraftTask(it, num(a, "count", 1));
            }
            case "fight": return new FightTask(false);
            case "protect": return new FightTask(true);
            case "eat": return new EatTask();
            case "equip": {
                String what = str(a, "item");
                return what.isEmpty() ? new EquipTask() : new EquipTask(what);
            }
            case "collect": return new CollectTask();
            case "place": {
                String what = str(a, "block");
                String[] p = MineTargets.findPlace(what);
                if (p == null) throw new IllegalArgumentException("Rykaah belum tahu cara menaruh '" + what + "'");
                return new PlaceTask(p[0], p[1], num(a, "count", 1));
            }
            case "use": {
                String what = str(a, "target");
                MineTargets.Target t = MineTargets.findUse(what);
                if (t == null) throw new IllegalArgumentException("Rykaah belum tahu cara memakai '" + what + "'");
                return new UseTask(t);
            }
            default: return null;
        }
    }

    /** @return catatan sistem untuk AI (kebenaran tentang apa yang baru dimulai/ditolak), atau null untuk obrolan biasa. */
    public String apply(ServerPlayerEntity owner, Intents.Intent in) {
        if (in.kind() == Intents.Kind.CHAT) return null;
        ServerPlayerEntity bot = Bot.get(server);
        debug("perintah dikenali: " + in.kind() + " | badan Rykaah " + (bot == null ? "TIDAK ADA di dunia" : bot.isDead() ? "mati" : "ada"));
        if (bot == null || bot.isDead()) return "Tubuh Rykaah belum muncul/sedang mati, jadi dia belum bisa melakukan apa pun.";
        switch (in.kind()) {
            case STOP -> {
                cancelAll();
                return "Rykaah berhenti dan diam di tempat; semua tugas dibatalkan.";
            }
            case FOLLOW -> {
                set(new FollowTask(false));
                return "Rykaah mulai mengikuti suaminya (berjalan sungguhan).";
            }
            case COME -> {
                set(new FollowTask(true));
                return "Rykaah mulai berjalan menghampiri suaminya. Belum sampai.";
            }
            case MINE -> {
                MineTargets.Target t = MineTargets.findMine(in.text());
                int n = in.number() > 0 ? in.number() : t.defaultCount();
                set(new MineTask(t, n));
                return "Rykaah mulai menghancurkan " + n + " " + t.label() + " yang terlihat di sekitarnya (hanya block yang terbuka ke udara). Belum selesai.";
            }
            case PLACE -> {
                String[] p = MineTargets.findPlace(in.text());
                int n = in.number() > 0 ? in.number() : 1;
                String extra = n > PlaceTask.MAX ? " (dibatasi maksimal " + PlaceTask.MAX + " per perintah)" : "";
                set(new PlaceTask(p[0], p[1], n));
                return "Rykaah mulai menaruh " + p[0] + " di depannya" + extra + ". Belum selesai.";
            }
            case USE -> {
                MineTargets.Target t = MineTargets.findUse(in.text());
                set(new UseTask(t));
                return "Rykaah mencari " + t.label() + " terdekat untuk dipakai. Belum selesai.";
            }
            case CRAFT -> {
                net.minecraft.item.Item it = ItemResolver.find(in.text());
                int n = Math.max(1, in.number());
                set(new CraftTask(it, n));
                return "Rykaah mulai membuat " + n + " " + ItemResolver.label(it) + " dari bahan di inventorinya (resep asli, bahan perantara dibuat otomatis). Belum selesai.";
            }
            case FIGHT -> {
                set(new FightTask(false));
                return "Rykaah mulai melawan monster hostil di sekitarnya (hanya monster; tidak menyerang pemain/hewan). Belum selesai.";
            }
            case PROTECT -> {
                set(new FightTask(true));
                return "Rykaah mulai menjaga suaminya: tetap dekat dan menyerang monster hostil yang mendekat. Berjalan terus sampai dibatalkan.";
            }
            case EAT -> {
                set(new EatTask());
                return "Rykaah mencoba makan dari inventorinya. Belum selesai.";
            }
            case EQUIP -> {
                set(new EquipTask());
                return "Rykaah mencoba memakai armor terbaik dari inventorinya.";
            }
            case UNSUPPORTED -> {
                return "Suami meminta sesuatu yang BELUM bisa dilakukan Rykaah sekarang (membangun, bertani, membeli di shop, terbang elytra, atau redstone). Jangan pura-pura sudah melakukannya; katakan jujur dengan gayamu bahwa belum bisa, dan tawarkan yang memang bisa: jalan/ikut, menggali, menaruh blok, memakai pintu/tuas, membuat item (crafting), melawan monster, menjaga suami, makan, memakai armor.";
            }
            default -> { return null; }
        }
    }

    private void set(Task t) {
        cancelAll();
        queue.add(t);
    }

    public void tick() {
        ServerPlayerEntity bot = Bot.get(server);
        if (bot == null || bot.isDead()) return;
        if (current == null) {
            current = queue.poll();
            started = false;
            if (current == null) return;
        }
        Task.Status st;
        try {
            if (!started) { current.start(this, bot); started = true; }
            st = current.tick(this, bot);
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Task {} crash: {}", current.describe(), e.toString());
            current.failReason = "terjadi error internal saat " + current.describe();
            st = Task.Status.FAILED;
        }
        current.age++;
        if (st == Task.Status.RUNNING && current.age > current.maxTicks()) {
            current.failReason = "waktu habis saat " + current.describe();
            st = Task.Status.FAILED;
        }
        if (st != Task.Status.RUNNING) {
            Task t = current;
            current = null;
            started = false;
            safeStop(t, bot);
            Bot.halt(server);
            if (st == Task.Status.DONE) {
                RykahMod.LOGGER.info("Tugas selesai: {}", t.doneMessage);
                if (RykahConfig.get().behavior.routineReports) RykahMod.reportNote(server, t.doneMessage);
            } else {
                RykahMod.reportNote(server, "Tugas '" + t.describe() + "' tidak berhasil. Alasan sebenarnya: " + t.failReason + ".");
            }
        }
    }
}
