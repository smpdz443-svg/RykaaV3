package com.example.rykah;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/rykah-config.json. Dibuat otomatis dengan nilai default kalau belum ada. */
public final class RykahConfig {
    public int version = 0;
    public Auth auth = new Auth();
    public Skin skin = new Skin();
    public Ai ai = new Ai();
    public Behavior behavior = new Behavior();

    public static final class Auth {
        public boolean enabled = true;
        public String password = "RIKA12345";
        /** Maksimum percobaan login dan register (masing-masing) per sesi spawn. */
        public int maxAttemptsPerKind = 2;
        /** Jendela waktu (tick) setelah spawn di mana pesan server dianggap prompt auth. */
        public int windowTicks = 1200;
        public int cooldownTicks = 40;
    }

    public static final class Skin {
        public boolean enabled = true;
        public String botName = "Rykaah_";
        /** "slim" (Alex) atau "classic" (Steve). */
        public String model = "slim";
    }

    public static final class Ai {
        public String primaryModel = "gemini-3.5-flash-lite";
        public String fallbackModel = "gemini-3.8-flash";
        public int maxHistoryMessages = 40;
        public int maxOutputTokens = 400;
        public double temperature = 1.0;
    }

    public static final class Behavior {
        /** Kosong = pemain pertama yang join jadi suami. Isi nama untuk mengunci. */
        public String ownerName = "";
        public boolean autoRespawn = true;
        public int respawnDelayTicks = 100;
        /** Jarak (blok) di mana Rykah teleport ke suami saat follow. 0 = tidak pernah teleport. */
        public int followTeleportDistance = 48;
        public int mineRadius = 16;
        /** Peluang Rykah membuka obrolan sendiri kira-kira tiap interval ini (tick; 2400 = 2 menit). */
        public int initiativeIntervalTicks = 2400;
        public boolean proactiveEnabled = true;
        /** Laporan rutin (tugas selesai dll) ke chat. Default MATI; kegagalan penting tetap dikabarkan secara natural. */
        public boolean routineReports = false;
        /** 1-10: seberapa intens sisi yandere/posesifnya. */
        public int intensity = 9;
        public boolean debug = false;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static RykahConfig instance;

    public static synchronized RykahConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static RykahConfig load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("rykah-config.json");
        RykahConfig cfg = new RykahConfig();
        try {
            if (Files.exists(file)) {
                RykahConfig read = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), RykahConfig.class);
                if (read != null) cfg = read;
            }
            cfg.validate();
            Files.writeString(file, GSON.toJson(cfg), StandardCharsets.UTF_8); // tulis balik (isi field baru)
        } catch (Exception e) {
            RykahMod.LOGGER.warn("Gagal membaca rykah-config.json, pakai default: {}", e.toString());
            cfg = new RykahConfig();
            cfg.validate();
        }
        return cfg;
    }

    private static final int CONFIG_VERSION = 2;

    private void validate() {
        if (auth == null) auth = new Auth();
        if (skin == null) skin = new Skin();
        if (ai == null) ai = new Ai();
        if (behavior == null) behavior = new Behavior();
        if (version < CONFIG_VERSION) { // migrasi: matikan debug chat dan percepat obrolan proaktif
            behavior.debug = false;
            behavior.initiativeIntervalTicks = 2400;
            version = CONFIG_VERSION;
        }
        behavior.intensity = Math.max(1, Math.min(10, behavior.intensity));
        if (auth.password == null || auth.password.isBlank() || auth.password.contains(" ")) {
            RykahMod.LOGGER.warn("auth.password tidak valid (kosong/ada spasi). Auth dimatikan.");
            auth.password = "RIKA12345";
            auth.enabled = false;
        }
        auth.maxAttemptsPerKind = Math.max(1, Math.min(auth.maxAttemptsPerKind, 5));
        auth.windowTicks = Math.max(200, auth.windowTicks);
        auth.cooldownTicks = Math.max(10, auth.cooldownTicks);
        if (skin.botName == null || skin.botName.isBlank()) skin.botName = "Rykaah_";
        if (!"classic".equalsIgnoreCase(skin.model)) skin.model = "slim";
        ai.maxHistoryMessages = Math.max(2, ai.maxHistoryMessages);
        ai.maxOutputTokens = Math.max(64, ai.maxOutputTokens);
        behavior.mineRadius = Math.max(4, Math.min(behavior.mineRadius, 24));
        behavior.respawnDelayTicks = Math.max(20, behavior.respawnDelayTicks);
        behavior.initiativeIntervalTicks = Math.max(600, behavior.initiativeIntervalTicks);
        if (behavior.ownerName == null) behavior.ownerName = "";
    }
}
