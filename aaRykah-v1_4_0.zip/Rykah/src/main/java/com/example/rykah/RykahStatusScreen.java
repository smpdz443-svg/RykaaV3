package com.example.rykah;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Layar status Rykah (dibuka dari menu jeda). Data dari ringkasan server yang diperbarui tiap detik; tidak mengirim apa pun ke chat. */
public final class RykahStatusScreen extends Screen {
    private final Screen parent;

    public RykahStatusScreen(Screen parent) {
        super(Text.literal("Status Rykah"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Kembali"), b -> close())
                .dimensions(this.width / 2 - 60, this.height - 28, 120, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFFFFF);
        List<String> lines = RykahMod.status();
        int y = 36;
        int x = Math.max(8, this.width / 2 - 150);
        for (String line : lines) {
            if (y > this.height - 40) break;
            ctx.drawTextWithShadow(this.textRenderer, line, x, y, 0xE0E0E0);
            y += 12;
        }
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }
}
