# Rykah (Fabric 1.21.1) v1.2.1 - Fase 1

Ditulis ulang dari jar lama (source asli tidak tersedia). Persona yandere (`rykaah_persona.txt`) dipakai persis apa adanya;
hanya blok "BODY AND ACTIVITIES" ditambah agar Rykah jujur soal kemampuan nyatanya.

## Build
Butuh JDK 21 dan Gradle 8.10.x (internet untuk unduh Loom/Minecraft):
    gradle build          # atau: gradle wrapper && ./gradlew build
Hasil: build/libs/rykah-1.2.0.jar. Versi Fabric API di gradle.properties bisa disesuaikan bila tidak ditemukan.

## Pasang
1. Fabric Loader 0.16.10+, Fabric API, dan Fabric Carpet (1.21.x) di server/dunia.
2. Taruh jar di mods/. Letakkan API key Gemini di config/gemini-companion-api-key.txt.
3. Edit config/rykah-config.json (dibuat otomatis): password (default RIKA12345), model skin, dll.
4. Skin slim bekerja di sisi client: pasang mod ini juga di client.

## Fitur Fase 1
- Mining nyata (waktu, alat, jangkauan, line-of-sight, verifikasi block hilang), ambil drop.
- Menaruh block (maks 4 berjajar), klik pintu/trapdoor/gerbang/tombol/tuas dengan verifikasi perubahan state.
- Jalan sungguhan lewat gerakan Carpet (garis lurus, lompat saat tertabrak). Follow/kemari.
- Kesadaran kondisi (satu baris ringkas ke AI), tugas dengan timeout/batal/laporan jujur.
- Kematian -> respawn terverifikasi -> lapor ke suami, tidak melanjutkan tugas lama.
- Auth otomatis berbasis deteksi pesan server (login/register, 1 atau 2 password), anti-spam.
- Skin slim dari config, ikon mod.

## Belum ada (Fase berikutnya, TIDAK diimplementasi)
Combat/PvP, Elytra, Water Bucket MLG, crafting, trading villager, toko server, build rumah, pathfinding, ambil barang drop kematian,
join server sebagai klien terpisah.


## v1.3.0 (Tahap A) - STATUS: BELUM DIKOMPILASI / BELUM DIUJI DI MINECRAFT
Ditulis tanpa akses Gradle/internet, jadi mungkin ada error kompilasi kecil (nama API Yarn). Jalankan `gradle build` dan kirim errornya bila ada.
Baru:
- CraftTask: crafting dari resep asli server, bahan perantara otomatis (papan, tongkat, dst), jalan ke crafting table bila resep 3x3, verifikasi jumlah item. Bahan mentah yang kurang -> gagal jujur (belum mengumpulkan sendiri).
- FightTask: melawan monster hostil / menjaga suami. Tidak pernah menyerang pemain, hewan, villager, atau mob netral yang tidak marah. Mundur saat HP rendah, makan bila perlu, kill dihitung hanya bila target benar-benar mati.
- EatTask, EquipTask (armor terbaik), Gear (senjata/makanan/armor).
- ItemResolver: nama item Indonesia/Inggris -> id registry (tanpa menebak).
- Intent UNSUPPORTED: permintaan bangun/farming/beli/elytra/redstone dijawab jujur "belum bisa" (mencegah klaim palsu).
- Persona: kepribadian TIDAK diubah; hanya blok fakta kemampuan diperbarui.
Belum: farming, build rumah, Elytra, MLG, redstone, shop, GUI server, join server sebagai klien terpisah, pathfinding sungguhan, ambil drop kematian.


## v1.4.0 (BELUM DIKOMPILASI / BELUM DIUJI DI MINECRAFT)
- Pemahaman perintah: AI (Gemini) memahami maksud dalam bahasa apa pun lalu mengeluarkan baris aksi <<ACT {...}>> yang dijalankan lewat task asli (ActionRouter + Brain.applyActions). Regex lama hanya dipakai untuk "stop" instan dan cadangan saat AI gagal.
- Laporan status otomatis di chat dimatikan: debug default mati (config dimigrasi), laporan tugas selesai mati (behavior.routineReports), konteks game dikirim sebagai info PRIBADI untuk AI. Kegagalan penting tetap dikabarkan 1 kalimat natural.
- Baru: TreeTask (tebang pohon utuh, hanya pohon alami), CollectTask, EquipTask dengan nama item (armor/elytra/perisai/alat, ambil item yang dijatuhkan).
- Obrolan proaktif ~2 menit (behavior.initiativeIntervalTicks=2400, variasi acak, sadar konteks, bisa menolak lewat <<SKIP>>, anti-ulang).
- Persona: blok tambahan (gaya bicara pendek, yandere lebih intens, level di behavior.intensity). Persona dasar tidak diubah.
- Layar "Status Rykah" di menu jeda (tepat di bawah tombol Video Settings bila ada, selain itu di bawah tombol paling bawah). Hanya single-player/integrated server.
Belum: skin kustom (GUI/URL/upload), memancing, farming, building, redstone, koneksi server publik.
